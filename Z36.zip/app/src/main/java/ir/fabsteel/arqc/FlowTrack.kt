package ir.fabsteel.arqc

import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * ردیابی جابه‌جایی گوشی بدون ARCore (نسخه‌ی ساده‌شده‌ی مکانیزم VIO):
 * جریان نوری Lucas-Kanade روی گوشه‌های تصویر + جبران چرخش با ژیروسکوپ + حل کمترمربعات برای جابه‌جایی دوربین.
 * ورودی: تصویر خاکستری ایستاده‌ی کوچک (حدود ۳۲۰×۲۴۰)؛ خروجی: جابه‌جایی دوربین (متر) در دستگاه دوربین (x راست، y بالا، z به عقب).
 */
class FlowTrack {
    private val maxF = 120
    private var w = 0
    private var h = 0
    private var prev0 = ByteArray(0)
    private var prev1 = ByteArray(0)
    private var cur1 = ByteArray(0)
    private val fx = FloatArray(maxF)
    private val fy = FloatArray(maxF)
    private var n = 0
    private var prevR: FloatArray? = null
    private var costA = 0f
    private var costB = 0f
    private var votes = 0
    @Volatile var useB = false
    @Volatile var inliers = 0

    private val tI = FloatArray(81)
    private val tX = FloatArray(81)
    private val tY = FloatArray(81)
    private val outP = FloatArray(2)

    fun reset() { n = 0; prevR = null; w = 0; votes = 0; costA = 0f; costB = 0f }

    private fun bil(img: ByteArray, W: Int, H: Int, x: Float, y: Float): Float {
        val x0 = x.toInt(); val y0 = y.toInt()
        val ax = x - x0; val ay = y - y0
        val i = y0 * W + x0
        val a = (img[i].toInt() and 0xFF).toFloat(); val b = (img[i + 1].toInt() and 0xFF).toFloat()
        val c = (img[i + W].toInt() and 0xFF).toFloat(); val d = (img[i + W + 1].toInt() and 0xFF).toFloat()
        return (a * (1 - ax) + b * ax) * (1 - ay) + (c * (1 - ax) + d * ax) * ay
    }

    /** LK تک‌سطحی؛ (gx,gy) حدس اولیه‌ی مختصات در تصویر جاری. true یعنی موفق، نتیجه در outP */
    private fun lk(p: ByteArray, c: ByteArray, W: Int, H: Int, x0: Float, y0: Float, gx0: Float, gy0: Float): Boolean {
        val r = 4
        if (x0 < r + 2 || y0 < r + 2 || x0 > W - r - 3 || y0 > H - r - 3) return false
        var gxx = 0f; var gxy = 0f; var gyy = 0f
        var k = 0
        for (j in -r..r) for (i in -r..r) {
            val xx = x0 + i; val yy = y0 + j
            tI[k] = bil(p, W, H, xx, yy)
            tX[k] = (bil(p, W, H, xx + 1, yy) - bil(p, W, H, xx - 1, yy)) * 0.5f
            tY[k] = (bil(p, W, H, xx, yy + 1) - bil(p, W, H, xx, yy - 1)) * 0.5f
            gxx += tX[k] * tX[k]; gxy += tX[k] * tY[k]; gyy += tY[k] * tY[k]
            k++
        }
        val det = gxx * gyy - gxy * gxy
        val tr = gxx + gyy
        val mn = tr / 2 - sqrt(max(0f, (gxx - gyy) * (gxx - gyy) / 4 + gxy * gxy))
        if (det < 1e-3f || mn < 150f) return false
        var gx = gx0; var gy = gy0
        for (it in 0 until 6) {
            if (gx < r + 2 || gy < r + 2 || gx > W - r - 3 || gy > H - r - 3) return false
            var ex = 0f; var ey = 0f
            k = 0
            for (j in -r..r) for (i in -r..r) {
                val dI = tI[k] - bil(c, W, H, gx + i, gy + j)
                ex += dI * tX[k]; ey += dI * tY[k]
                k++
            }
            val dx = (gyy * ex - gxy * ey) / det
            val dy = (gxx * ey - gxy * ex) / det
            gx += dx; gy += dy
            if (abs(dx) < 0.03f && abs(dy) < 0.03f) break
        }
        outP[0] = gx; outP[1] = gy
        return true
    }

    private fun detect(g: ByteArray, W: Int, H: Int) {
        val cs = 40
        val ncx = W / cs; val ncy = H / cs
        val occ = BooleanArray(ncx * ncy)
        for (i in 0 until n) {
            val cx = (fx[i] / cs).toInt().coerceIn(0, ncx - 1); val cy = (fy[i] / cs).toInt().coerceIn(0, ncy - 1)
            occ[cy * ncx + cx] = true
        }
        for (cy in 0 until ncy) for (cx in 0 until ncx) {
            if (occ[cy * ncx + cx] || n >= maxF) continue
            var best = 0f; var bx = -1; var by = -1
            var y = cy * cs + 8
            while (y < (cy + 1) * cs - 8) {
                var x = cx * cs + 8
                while (x < (cx + 1) * cs - 8) {
                    if (x >= 10 && y >= 10 && x < W - 10 && y < H - 10) {
                        var a = 0f; var b = 0f; var c = 0f
                        for (j in -2..2) for (i in -2..2) {
                            val idx = (y + j) * W + (x + i)
                            val gx = ((g[idx + 1].toInt() and 0xFF) - (g[idx - 1].toInt() and 0xFF)).toFloat()
                            val gy = ((g[idx + W].toInt() and 0xFF) - (g[idx - W].toInt() and 0xFF)).toFloat()
                            a += gx * gx; b += gx * gy; c += gy * gy
                        }
                        val lam = (a + c) / 2 - sqrt(max(0f, (a - c) * (a - c) / 4 + b * b))
                        if (lam > best) { best = lam; bx = x; by = y }
                    }
                    x += 2
                }
                y += 2
            }
            if (bx >= 0 && best > 6000f) { fx[n] = bx.toFloat(); fy[n] = by.toFloat(); n++ }
        }
    }

    private fun mmul3(a: FloatArray, b: FloatArray): FloatArray {
        val o = FloatArray(9)
        for (i in 0..2) for (j in 0..2) o[i * 3 + j] = a[i * 3] * b[j] + a[i * 3 + 1] * b[3 + j] + a[i * 3 + 2] * b[6 + j]
        return o
    }
    private fun tr3(a: FloatArray) = floatArrayOf(a[0], a[3], a[6], a[1], a[4], a[7], a[2], a[5], a[8])

    // نتیجه: [a, b, c, cost, inliers]
    private fun solve(x0: FloatArray, y0: FloatArray, x1: FloatArray, y1: FloatArray, cnt: Int, rel: FloatArray, kn: Float, cxp: Float, cyp: Float): FloatArray? {
        val px = FloatArray(cnt); val pv = FloatArray(cnt); val fxs = FloatArray(cnt); val fvs = FloatArray(cnt)
        var m = 0
        for (i in 0 until cnt) {
            val xn = (x0[i] - cxp) * kn; val vn = (y0[i] - cyp) * kn
            val rx = rel[0] * xn + rel[1] * (-vn) + rel[2] * (-1f)
            val ry = rel[3] * xn + rel[4] * (-vn) + rel[5] * (-1f)
            val rz = rel[6] * xn + rel[7] * (-vn) + rel[8] * (-1f)
            if (rz > -0.2f) continue
            val xp = rx / (-rz); val vp = ry / rz
            px[m] = xp; pv[m] = vp
            fxs[m] = (x1[i] - cxp) * kn - xp
            fvs[m] = (y1[i] - cyp) * kn - vp
            m++
        }
        if (m < 12) return null
        var a = 0f; var b = 0f; var c = 0f
        val wgt = FloatArray(m) { 1f }
        val s = 1.5f * kn
        for (it in 0 until 4) {
            // معادلات نرمال برای θ=(a,b,c): fx = a − x·c ؛ fv = b − v·c
            var s11 = 0f; var s13 = 0f; var s22 = 0f; var s23 = 0f; var s33 = 0f; var r1 = 0f; var r2 = 0f; var r3 = 0f
            for (i in 0 until m) {
                val wi = wgt[i]
                s11 += wi; s13 += -wi * px[i]; s22 += wi; s23 += -wi * pv[i]
                s33 += wi * (px[i] * px[i] + pv[i] * pv[i])
                r1 += wi * fxs[i]; r2 += wi * fvs[i]
                r3 += wi * (-px[i] * fxs[i] - pv[i] * fvs[i])
            }
            // [s11 0 s13; 0 s22 s23; s13 s23 s33] θ = [r1 r2 r3]
            val det = s11 * (s22 * s33 - s23 * s23) - s13 * (s22 * s13)
            if (abs(det) < 1e-12f) return null
            val m3 = arrayOf(floatArrayOf(s11, 0f, s13), floatArrayOf(0f, s22, s23), floatArrayOf(s13, s23, s33))
            val rr = floatArrayOf(r1, r2, r3)
            val dd = det3(m3)
            if (abs(dd) < 1e-12f) return null
            val sol = FloatArray(3)
            for (col in 0..2) {
                val mm = arrayOf(m3[0].clone(), m3[1].clone(), m3[2].clone())
                for (row in 0..2) mm[row][col] = rr[row]
                sol[col] = det3(mm) / dd
            }
            a = sol[0]; b = sol[1]; c = sol[2]
            for (i in 0 until m) {
                val ex = fxs[i] - (a - px[i] * c); val ev = fvs[i] - (b - pv[i] * c)
                val e2 = (ex * ex + ev * ev) / (s * s)
                wgt[i] = 1f / (1f + e2)
            }
        }
        var cost = 0f; var inl = 0
        for (i in 0 until m) {
            val ex = fxs[i] - (a - px[i] * c); val ev = fvs[i] - (b - pv[i] * c)
            val e2 = (ex * ex + ev * ev) / (s * s)
            cost += min(e2, 16f)
            if (e2 < 4f) inl++
        }
        return floatArrayOf(a, b, c, cost / m, inl.toFloat())
    }

    private fun det3(m: Array<FloatArray>): Float =
        m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1]) - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0]) + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0])

    /** gray: تصویر ایستاده W×H ؛ r: چرخش ژیروسکوپ (دوربین→مرجع) ؛ kn: نرمال‌سازی هر پیکسل ؛ depth: عمق تقریبی قطعه (m) */
    fun step(gray: ByteArray, W: Int, H: Int, r: FloatArray, kn: Float, depth: Float): FloatArray? {
        if (W != w || H != h) { w = W; h = H; prev0 = ByteArray(W * H); prev1 = ByteArray((W / 2) * (H / 2)); cur1 = ByteArray((W / 2) * (H / 2)); n = 0; prevR = null }
        val w2 = W / 2; val h2 = H / 2
        for (y in 0 until h2) for (x in 0 until w2) {
            val i = 2 * y * W + 2 * x
            cur1[y * w2 + x] = (((gray[i].toInt() and 0xFF) + (gray[i + 1].toInt() and 0xFF) + (gray[i + W].toInt() and 0xFF) + (gray[i + W + 1].toInt() and 0xFF)) shr 2).toByte()
        }
        var result: FloatArray? = null
        val pr = prevR
        if (n > 0 && pr != null) {
            val x0 = FloatArray(n); val y0 = FloatArray(n); val x1 = FloatArray(n); val y1 = FloatArray(n)
            var k = 0
            for (i in 0 until n) {
                var ok = lk(prev1, cur1, w2, h2, fx[i] / 2f, fy[i] / 2f, fx[i] / 2f, fy[i] / 2f)
                if (!ok) continue
                val gx1 = outP[0] * 2f; val gy1 = outP[1] * 2f
                ok = lk(prev0, gray, W, H, fx[i], fy[i], gx1, gy1)
                if (!ok) continue
                val ddx = outP[0] - fx[i]; val ddy = outP[1] - fy[i]
                if (abs(ddx) > 40f || abs(ddy) > 40f) continue
                x0[k] = fx[i]; y0[k] = fy[i]; x1[k] = outP[0]; y1[k] = outP[1]; k++
            }
            n = 0
            for (i in 0 until k) { fx[n] = x1[i]; fy[n] = y1[i]; n++ }
            val relA = mmul3(tr3(r), pr)                  // دوربین۱ → دوربین۲
            val relB = tr3(relA)
            val ang = acos(((relA[0] + relA[4] + relA[8] - 1f) / 2f).coerceIn(-1f, 1f))
            val cxp = W / 2f; val cyp = H / 2f
            val sa = solve(x0, y0, x1, y1, k, relA, kn, cxp, cyp)
            val sb = solve(x0, y0, x1, y1, k, relB, kn, cxp, cyp)
            if (sa != null && sb != null && ang > 0.004f) {
                costA += sa[3]; costB += sb[3]; votes++
                if (votes >= 8) { if (costB < costA * 0.85f) useB = true else if (costA < costB * 0.85f) useB = false }
                if (votes > 400) { costA *= 0.5f; costB *= 0.5f; votes = 200 }
            }
            val s = if (useB) sb else sa
            if (s != null && s[4] >= 12f) {
                inliers = s[4].toInt()
                var a = s[0]; var b = s[1]; var c = s[2]
                val dead = 0.0006f
                if (abs(a) < dead) a = 0f
                if (abs(b) < dead) b = 0f
                if (abs(c) < dead) c = 0f
                result = floatArrayOf(-a * depth, b * depth, 0.5f * c * depth)
            } else inliers = 0
        }
        if (n < 70) detect(gray, W, H)
        System.arraycopy(gray, 0, prev0, 0, W * H)
        System.arraycopy(cur1, 0, prev1, 0, w2 * h2)
        prevR = r.clone()
        return result
    }
}
