package ir.fabsteel.arqc

import android.content.Context
import android.graphics.Bitmap
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.view.Surface
import android.view.WindowManager
import com.google.ar.core.Anchor
import com.google.ar.core.Camera
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.google.ar.core.Coordinates2d
import com.google.ar.core.DepthPoint
import com.google.ar.core.Frame
import com.google.ar.core.Plane
import com.google.ar.core.Point
import com.google.ar.core.Pose
import com.google.ar.core.Session
import com.google.ar.core.TrackingState
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.max
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

class QcRow(val name: String, val isHole: Boolean, val devMm: Float, val tolMm: Float, val ok: Boolean)

class QcResult(
    val evaluated: Int,
    val okCount: Int,
    val mismatch: Int,
    val worstDevMm: Float,
    val worstName: String,
    val noiseLimited: Boolean,
    val rows: List<QcRow>
) {
    val percent: Int get() = if (evaluated == 0) 0 else okCount * 100 / evaluated
}

class ArRenderer(private val ctx: Context, private val listener: Listener) : GLSurfaceView.Renderer {

    interface Listener {
        fun onStatus(tracking: Boolean, quality: Int, depthOk: Boolean, hasHit: Boolean)
        fun onQc(r: QcResult)
        fun onSnapshot(bmp: Bitmap)
        fun onFixed(fixed: Boolean)
        /** distMm >= 0: فاصله‌ی دو نقطه ؛ -1: هنوز نقطه‌ی دوم لازم است ؛ -2: سطحی زیر انگشت پیدا نشد */
        fun onMeasure(distMm: Float, count: Int)
    }

    // ---- ابزارهای فیلم: برش، شفافیت، متر ----
    @Volatile var fillAlpha = 0.35f
    @Volatile var clipOn = false
    @Volatile var clipAxis = 1             // 0=X ، 1=Y (بالا) ، 2=Z ؛ در دستگاه مختصات خود مدل
    @Volatile var clipPos = 1f             // 0..1 از ابعاد مدل روی همان محور
    @Volatile var clipFlip = false
    @Volatile var tapX = -1f
    @Volatile var tapY = -1f
    private val mPts = ArrayList<FloatArray>()
    private val mBuf: FloatBuffer = fb(FloatArray(48))
    private var lnAxis = 0
    private var lnD = 0
    private var lnClipOn = 0

    fun clearMeasure() {
        synchronized(mPts) { mPts.clear() }
        listener.onMeasure(-1f, 0)
    }

    @Volatile var session: Session? = null
    @Volatile var tolMemberMm = 5f
    @Volatile var tolHoleMm = 3f
    @Volatile var noisePct = 1.0f          // حد نویز حسگر عمق، درصد فاصله
    @Volatile var yawDeg = 0f
    @Volatile var fixRequest = 0           // 1 = فیکس ، 2 = آزاد
    @Volatile var snapRequest = false
    @Volatile var depthEnabled = false
    private var pendingModel: IfcModel? = null
    private var clearModel = false

    // ---- GL ----
    private var camTex = 0
    private var bgProg = 0
    private var lineProg = 0
    private var bgPos = 0
    private var bgUv = 0
    private var lnPos = 0
    private var lnMvp = 0
    private var lnColor = 0
    private val quad: FloatBuffer = fb(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f))
    private val uvBuf: FloatBuffer = fb(FloatArray(8))
    private val quadArr = floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)
    private val uvArr = FloatArray(8)
    private var vw = 1
    private var vh = 1
    private var boundSession: Session? = null

    // همه‌ی قطعات در دو بافر بزرگ (خطوط و مثلث‌ها) هستند؛ هر قطعه فقط محدوده‌ی خودش را دارد.
    private class Gpu(val m: Member, val firstE: Int, val nE: Int, val firstT: Int, val nT: Int) {
        @Volatile var red = false
        var dev = -1f              // اختلاف میانه (mm)؛ منفی = هنوز بررسی نشده
        var tol = 0f
        var noiseLimited = false
    }

    private var gpu: List<Gpu> = emptyList()
    private var bigE = 0
    private var bigT = 0
    private var totE = 0
    private var totT = 0
    private var qcCursor = 0

    // ---- وضعیت AR ----
    private var anchor: Anchor? = null
    private var fixed = false
    private var lastHit: Pose? = null
    private var lastQcMs = 0L
    private var lastStatusMs = 0L

    private val proj = FloatArray(16)
    private val view = FloatArray(16)
    private val vp = FloatArray(16)
    private val mdl = FloatArray(16)
    private val mvp = FloatArray(16)
    private val mv = FloatArray(16)


    // ---- قفل خودکار با هولوگرام (QR) روی ARCore ----
    @Volatile var markerMode = true
    @Volatile var gravitySnap = true
    @Volatile var onMarkerMsg: ((String) -> Unit)? = null
    @Volatile var onNeedModel: ((String) -> Unit)? = null
    private var markerAnchor = false
    private val qr by lazy { BarcodeScanning.getClient(BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build()) }
    private var nv21 = ByteArray(0)
    @Volatile private var scanBusy = false
    private var lastScan = 0L
    private var holdOffUntil = 0L
    private val samples = ArrayList<FloatArray>()      // هر نمونه: محورهای X,Y,Z مارکر در دنیا (9) + مبدأ (3)
    private var smFace = -1
    private var smDy = 0f
    private var smU = -1f
    private var smV = 0.5f
    private var smId = ""
    private val NS = 14
    private var lastNeedMs = 0L

    private fun msg(t: String) { onMarkerMsg?.invoke(t) }

    private fun scanMarker(frame: Frame, cam: Camera, now: Long) {
        if (scanBusy || now - lastScan < 150) return
        if (ModelStore.model == null) { msg("اول فایل .qcar (یا IFC) را بارگذاری کنید"); return }
        lastScan = now
        val img = try { frame.acquireCameraImage() } catch (e: Exception) { return }
        var w = 0; var h = 0
        try {
            w = img.width; h = img.height
            val pl = img.planes[0]
            val rs = pl.rowStride
            val buf = pl.buffer.duplicate()
            val total = w * h * 3 / 2
            if (nv21.size != total) nv21 = ByteArray(total)
            for (y in 0 until h) {
                val st = y * rs
                if (st + w > buf.limit()) return
                buf.position(st); buf.get(nv21, y * w, w)
            }
            java.util.Arrays.fill(nv21, w * h, total, 128.toByte())
        } finally { img.close() }
        val ii = cam.imageIntrinsics
        val dim = ii.imageDimensions
        val sx = w.toFloat() / dim[0]; val sy = h.toFloat() / dim[1]
        val fx = ii.focalLength[0] * sx; val fy = ii.focalLength[1] * sy
        val ccx = ii.principalPoint[0] * sx; val ccy = ii.principalPoint[1] * sy
        val camPose = cam.pose
        val image = InputImage.fromByteArray(nv21, w, h, 0, InputImage.IMAGE_FORMAT_NV21)
        scanBusy = true
        qr.process(image)
            .addOnSuccessListener { list ->
                scanBusy = false
                try { onCodes(list, camPose, fx, fy, ccx, ccy) } catch (e: Exception) { msg("خطا: ${e.message}") }
            }
            .addOnFailureListener { scanBusy = false }
    }

    private fun onCodes(list: List<Barcode>, camPose: Pose, fx: Float, fy: Float, ccx: Float, ccy: Float) {
        if (fixed) return
        if (list.isEmpty()) {
            synchronized(samples) { if (samples.isNotEmpty() && System.currentTimeMillis() - lastScan > 1500) samples.clear() }
            msg("دوربین را روی هولوگرام (QR) بگیرید — فاصله ۳۰ تا ۶۰ سانتی‌متر، نور کافی")
            return
        }
        for (b in list) {
            val parts = (b.rawValue ?: continue).split("|")
            var id = ""; var face = -1; var codeMm = 50f; var dyMm = 0f; var au = -1f; var av = 0.5f
            if (parts[0] == "FQ1" && parts.size >= 2) face = parts[1].toIntOrNull() ?: -1
            else if (parts[0] == "FQ2" && parts.size >= 4) {
                id = parts[1]; face = parts[2].toIntOrNull() ?: -1; codeMm = parts[3].toFloatOrNull() ?: 50f
                if (parts.size >= 5) dyMm = parts[4].toFloatOrNull() ?: 0f
            } else if (parts[0] == "FQ3" && parts.size >= 7) {
                id = parts[1]; face = parts[2].toIntOrNull() ?: -1; codeMm = parts[3].toFloatOrNull() ?: 50f
                dyMm = parts[4].toFloatOrNull() ?: 0f
                au = parts[5].toFloatOrNull() ?: -1f; av = parts[6].toFloatOrNull() ?: 0.5f
            } else continue
            val cp = b.cornerPoints ?: continue
            if (cp.size != 4 || face < 0 || face > 5) continue
            if (id.isNotEmpty() && id != ModelStore.id) {
                val n = System.currentTimeMillis()
                if (n - lastNeedMs > 2000) { lastNeedMs = n; onNeedModel?.invoke(id) }
                return
            }
            val us = FloatArray(4); val vs = FloatArray(4)
            for (i in 0..3) { us[i] = (cp[i].x - ccx) / fx; vs[i] = (cp[i].y - ccy) / fy }
            val codeM = codeMm / 1000f
            val rc = markerPose(us, vs, codeM) ?: continue
            val dist = sqrt(rc[9] * rc[9] + rc[10] * rc[10] + rc[11] * rc[11])
            if (dist < 0.08f || dist > 2.5f) { msg("فاصله‌ی مناسب ۳۰ تا ۶۰ سانتی‌متر است"); return }
            // ستون‌های مارکر در دستگاه GL دوربین (CV → GL با y,z وارونه)
            val smp = FloatArray(12)
            for (j in 0..2) {
                val wv = camPose.rotateVector(floatArrayOf(rc[j], -rc[3 + j], -rc[6 + j]))
                smp[3 * j] = wv[0]; smp[3 * j + 1] = wv[1]; smp[3 * j + 2] = wv[2]
            }
            val tw = camPose.transformPoint(floatArrayOf(rc[9], -rc[10], -rc[11]))
            smp[9] = tw[0]; smp[10] = tw[1]; smp[11] = tw[2]
            var n = 0
            synchronized(samples) {
                if (face != smFace || id != smId) samples.clear()
                smFace = face; smId = id; smDy = dyMm / 1000f; smU = au; smV = av
                samples.add(smp); n = samples.size
            }
            msg("در حال برداشت موقعیت قطعه… $n/$NS")
            return
        }
    }

    private fun tryLock(s: Session, now: Long) {
        val model = ModelStore.model ?: return
        val snap: List<FloatArray>
        synchronized(samples) { if (samples.size < NS) return; snap = ArrayList(samples); samples.clear() }
        // میانگین‌گیری مقاوم: حذف نمونه‌هایی که عمود مارکر آن‌ها از میانه دور است
        var nx = 0f; var ny = 0f; var nz = 0f
        for (a in snap) { nx += a[6]; ny += a[7]; nz += a[8] }
        val nl = sqrt(nx * nx + ny * ny + nz * nz)
        if (nl < 1e-6f) return
        nx /= nl; ny /= nl; nz /= nl
        val keep = snap.filter { it[6] * nx + it[7] * ny + it[8] * nz > 0.9659f }
        if (keep.size < 6) { msg("دوربین را ثابت‌تر نگه دارید…"); return }
        fun med(k: Int): Float { val v = keep.map { it[k] }.sorted(); return v[v.size / 2] }
        val tw = floatArrayOf(med(9), med(10), med(11))
        var ax = FloatArray(3); var ay = FloatArray(3)
        for (a in keep) for (i in 0..2) { ax[i] += a[i]; ay[i] += a[3 + i] }
        fun nrm(v: FloatArray): FloatArray { val l = sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]); return floatArrayOf(v[0] / l, v[1] / l, v[2] / l) }
        val X = nrm(ax)
        val d = ay[0] * X[0] + ay[1] * X[1] + ay[2] * X[2]
        val Y = nrm(floatArrayOf(ay[0] - d * X[0], ay[1] - d * X[1], ay[2] - d * X[2]))
        val Z = floatArrayOf(X[1] * Y[2] - X[2] * Y[1], X[2] * Y[0] - X[0] * Y[2], X[0] * Y[1] - X[1] * Y[0])
        // Rw (ستون‌ها X,Y,Z) ؛ سطری: rw[i*3+j]
        val rw = floatArrayOf(X[0], Y[0], Z[0], X[1], Y[1], Z[1], X[2], Y[2], Z[2])

        // قاب مارکر در دستگاه مدل (مثل QcCamActivity.setFromMarker)
        val sz = model.sizeM
        val fr = faceFrame(smFace, sz)
        var k: Float; var ky: Float
        if (smU >= 0f) {
            val wf = abs(fr[3] * sz[0] + fr[4] * sz[1] + fr[5] * sz[2])
            val hf = abs(fr[6] * sz[0] + fr[7] * sz[1] + fr[8] * sz[2])
            k = smU * wf; ky = smV * hf + smDy / 2f
        } else { k = 0.05f; ky = 0.05f + smDy }
        val pm = floatArrayOf(fr[0] + k * fr[3] + ky * fr[6], fr[1] + k * fr[4] + ky * fr[7], fr[2] + k * fr[5] + ky * fr[8])
        val mx = floatArrayOf(fr[3], fr[4], fr[5]); val my = floatArrayOf(fr[6], fr[7], fr[8])
        val mz = floatArrayOf(mx[1] * my[2] - mx[2] * my[1], mx[2] * my[0] - mx[0] * my[2], mx[0] * my[1] - mx[1] * my[0])
        val rmT = floatArrayOf(mx[0], mx[1], mx[2], my[0], my[1], my[2], mz[0], mz[1], mz[2])
        var m = FloatArray(9)
        for (i in 0..2) for (j in 0..2) { var t = 0f; for (q in 0..2) t += rw[i * 3 + q] * rmT[q * 3 + j]; m[i * 3 + j] = t }

        // تراز با جاذبه: اگر «بالا»ی مدل نزدیک بالای دنیاست، دقیقاً بالا شود
        if (gravitySnap) {
            val ux = m[1]; val uy = m[4]; val uz = m[7]
            val ang = acos(uy.coerceIn(-1f, 1f))
            if (ang in 0.0005f..0.2618f) {
                var axx = -uz; var axz = ux                          // u × (0,1,0)
                val al = sqrt(axx * axx + axz * axz)
                if (al > 1e-6f) {
                    axx /= al; axz /= al
                    val c = cos(ang); val sn = sin(ang); val oc = 1 - c
                    val r = floatArrayOf(
                        c + axx * axx * oc, -axz * sn, axx * axz * oc,
                        axz * sn, c, -axx * sn,
                        axz * axx * oc, axx * sn, c + axz * axz * oc)
                    val m2 = FloatArray(9)
                    for (i in 0..2) for (j in 0..2) { var t = 0f; for (q in 0..2) t += r[i * 3 + q] * m[q * 3 + j]; m2[i * 3 + j] = t }
                    m = m2
                }
            }
        }
        val tr = floatArrayOf(
            tw[0] - (m[0] * pm[0] + m[1] * pm[1] + m[2] * pm[2]),
            tw[1] - (m[3] * pm[0] + m[4] * pm[1] + m[5] * pm[2]),
            tw[2] - (m[6] * pm[0] + m[7] * pm[1] + m[8] * pm[2]))
        val q = quatOf(m)
        anchor?.detach()
        anchor = s.createAnchor(Pose(tr, q))
        markerAnchor = true
        fixed = true
        resetStates()
        listener.onFixed(true)
        msg("✔ مدل روی قطعه قفل شد — دور قطعه بگردید")
    }

    private fun quatOf(m: FloatArray): FloatArray {
        val tr = m[0] + m[4] + m[8]
        val qx: Float; val qy: Float; val qz: Float; val qw: Float
        if (tr > 0f) {
            val sq = sqrt(tr + 1f) * 2f
            qw = 0.25f * sq; qx = (m[7] - m[5]) / sq; qy = (m[2] - m[6]) / sq; qz = (m[3] - m[1]) / sq
        } else if (m[0] > m[4] && m[0] > m[8]) {
            val sq = sqrt(1f + m[0] - m[4] - m[8]) * 2f
            qw = (m[7] - m[5]) / sq; qx = 0.25f * sq; qy = (m[1] + m[3]) / sq; qz = (m[2] + m[6]) / sq
        } else if (m[4] > m[8]) {
            val sq = sqrt(1f + m[4] - m[0] - m[8]) * 2f
            qw = (m[2] - m[6]) / sq; qx = (m[1] + m[3]) / sq; qy = 0.25f * sq; qz = (m[5] + m[7]) / sq
        } else {
            val sq = sqrt(1f + m[8] - m[0] - m[4]) * 2f
            qw = (m[3] - m[1]) / sq; qx = (m[2] + m[6]) / sq; qy = (m[5] + m[7]) / sq; qz = 0.25f * sq
        }
        return floatArrayOf(qx, qy, qz, qw)
    }

    fun setModel(m: IfcModel?) { synchronized(this) { pendingModel = m; clearModel = m == null } }

    private fun fb(a: FloatArray): FloatBuffer =
        ByteBuffer.allocateDirect(a.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply { put(a); position(0) }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        val t = IntArray(1)
        GLES20.glGenTextures(1, t, 0)
        camTex = t[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, camTex)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)

        bgProg = program(
            "attribute vec4 a_Position; attribute vec2 a_Uv; varying vec2 v_Uv; void main(){ gl_Position=a_Position; v_Uv=a_Uv; }",
            "#extension GL_OES_EGL_image_external : require\nprecision mediump float; varying vec2 v_Uv; uniform samplerExternalOES s; void main(){ gl_FragColor=texture2D(s,v_Uv); }"
        )
        bgPos = GLES20.glGetAttribLocation(bgProg, "a_Position")
        bgUv = GLES20.glGetAttribLocation(bgProg, "a_Uv")
        lineProg = program(
            "uniform mat4 u_Mvp; attribute vec3 a_Pos; varying vec3 v_Local; " +
                "void main(){ v_Local=a_Pos; gl_Position=u_Mvp*vec4(a_Pos,1.0); }",
            "#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\n" +
                "uniform vec4 u_Color; uniform vec3 u_Axis; uniform float u_D; uniform float u_ClipOn; varying vec3 v_Local; " +
                "void main(){ if(u_ClipOn>0.5 && dot(v_Local,u_Axis)>u_D) discard; gl_FragColor=u_Color; }"
        )
        lnPos = GLES20.glGetAttribLocation(lineProg, "a_Pos")
        lnMvp = GLES20.glGetUniformLocation(lineProg, "u_Mvp")
        lnColor = GLES20.glGetUniformLocation(lineProg, "u_Color")
        lnAxis = GLES20.glGetUniformLocation(lineProg, "u_Axis")
        lnD = GLES20.glGetUniformLocation(lineProg, "u_D")
        lnClipOn = GLES20.glGetUniformLocation(lineProg, "u_ClipOn")
        boundSession = null
        gpu = emptyList()                   // بافرهای قبلی با از دست رفتن context بی‌اعتبارند
        bigE = 0; bigT = 0; totE = 0; totT = 0
        synchronized(this) { if (ModelStore.model != null && pendingModel == null) pendingModel = ModelStore.model }
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        vw = width; vh = height
        GLES20.glViewport(0, 0, width, height)
        boundSession = null
    }

    @Suppress("DEPRECATION")
    private fun rotation(): Int =
        (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay?.rotation ?: Surface.ROTATION_90

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        uploadPending()
        val s = session ?: return
        if (boundSession !== s) {
            s.setCameraTextureName(camTex)
            s.setDisplayGeometry(rotation(), vw, vh)
            boundSession = s
        }
        val frame: Frame = try { s.update() } catch (e: Exception) { return }
        val cam = frame.camera
        if (frame.timestamp != 0L) drawBackground(frame)

        val tracking = cam.trackingState == TrackingState.TRACKING
        val now = System.currentTimeMillis()

        if (tracking) {
            if (!fixed) {
                var hp: Pose? = null
                for (h in frame.hitTest(vw / 2f, vh / 2f)) {
                    val tr = h.trackable
                    if ((tr is Plane && tr.isPoseInPolygon(h.hitPose)) || tr is Point || tr is DepthPoint) {
                        hp = h.hitPose; break
                    }
                }
                lastHit = hp
            }
            val fr = fixRequest
            if (fr == 1 && !fixed && lastHit != null) {
                anchor?.detach()
                anchor = s.createAnchor(Pose(lastHit!!.translation, floatArrayOf(0f, 0f, 0f, 1f)))
                markerAnchor = false
                fixed = true
                listener.onFixed(true)
            } else if (fr == 2 && fixed) {
                anchor?.detach(); anchor = null; fixed = false; markerAnchor = false
                synchronized(samples) { samples.clear() }
                holdOffUntil = now + 3000
                resetStates()
                listener.onFixed(false)
            }
            fixRequest = 0
            if (!fixed && markerMode && now >= holdOffUntil && gpu.isNotEmpty()) {
                scanMarker(frame, cam, now)
                tryLock(s, now)
            }
        } else fixRequest = 0

        if (now - lastStatusMs > 250) {
            lastStatusMs = now
            var q = 0
            if (tracking) {
                val pc = frame.acquirePointCloud()
                try { q = minOf(100, pc.points.remaining() / 4 * 100 / 120) } finally { pc.release() }
            }
            listener.onStatus(tracking, q, depthEnabled, lastHit != null || fixed)
        }

        val base: FloatArray? = when {
            fixed && anchor?.trackingState == TrackingState.TRACKING -> anchor!!.pose.translation
            !fixed -> if (markerMode) null else lastHit?.translation
            else -> null
        }
        if (!tracking) { maybeSnap(); return }

        cam.getProjectionMatrix(proj, 0, 0.05f, 50f)
        cam.getViewMatrix(view, 0)
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0)
        handleTap(frame)

        if (base != null && gpu.isNotEmpty()) {
            if (fixed && markerAnchor) anchor!!.pose.toMatrix(mdl, 0)
            else {
                Matrix.setIdentityM(mdl, 0)
                Matrix.translateM(mdl, 0, base[0], base[1], base[2])
                Matrix.rotateM(mdl, 0, yawDeg, 0f, 1f, 0f)
            }
            Matrix.multiplyMM(mvp, 0, vp, 0, mdl, 0)
            Matrix.multiplyMM(mv, 0, view, 0, mdl, 0)
            drawModel()
            if (fixed && depthEnabled && now - lastQcMs > 500) {
                lastQcMs = now
                runQc(frame)
            }
        }
        drawMeasure()
        maybeSnap()
    }

    // ---------- ابزار متر ----------
    private fun handleTap(frame: Frame) {
        val x = tapX
        val y = tapY
        if (x < 0f) return
        tapX = -1f; tapY = -1f
        for (h in frame.hitTest(x, y)) {
            val tr = h.trackable
            if ((tr is Plane && tr.isPoseInPolygon(h.hitPose)) || tr is Point || tr is DepthPoint) {
                val t = h.hitPose.translation
                var d = -1f
                var n = 0
                synchronized(mPts) {
                    if (mPts.size >= 2) mPts.clear()
                    mPts.add(floatArrayOf(t[0], t[1], t[2]))
                    n = mPts.size
                    if (n == 2) {
                        val a = mPts[0]; val b = mPts[1]
                        val dx = a[0] - b[0]; val dy = a[1] - b[1]; val dz = a[2] - b[2]
                        d = sqrt(dx * dx + dy * dy + dz * dz) * 1000f
                    }
                }
                listener.onMeasure(d, n)
                return
            }
        }
        listener.onMeasure(-2f, synchronized(mPts) { mPts.size })
    }

    private fun drawMeasure() {
        val pts = synchronized(mPts) { ArrayList(mPts) }
        if (pts.isEmpty()) return
        val a = FloatArray(48)
        var n = 0
        fun add(x: Float, y: Float, z: Float) { a[n++] = x; a[n++] = y; a[n++] = z }
        val r = 0.02f
        for (p in pts) {
            add(p[0] - r, p[1], p[2]); add(p[0] + r, p[1], p[2])
            add(p[0], p[1] - r, p[2]); add(p[0], p[1] + r, p[2])
            add(p[0], p[1], p[2] - r); add(p[0], p[1], p[2] + r)
        }
        if (pts.size == 2) {
            add(pts[0][0], pts[0][1], pts[0][2]); add(pts[1][0], pts[1][1], pts[1][2])
        }
        mBuf.position(0); mBuf.put(a, 0, n); mBuf.position(0)
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glUseProgram(lineProg)
        GLES20.glUniformMatrix4fv(lnMvp, 1, false, vp, 0)
        GLES20.glUniform1f(lnClipOn, 0f)
        GLES20.glUniform4f(lnColor, 1f, 0.85f, 0.1f, 1f)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        GLES20.glEnableVertexAttribArray(lnPos)
        GLES20.glVertexAttribPointer(lnPos, 3, GLES20.GL_FLOAT, false, 0, mBuf)
        GLES20.glLineWidth(5f)
        GLES20.glDrawArrays(GLES20.GL_LINES, 0, n / 3)
        GLES20.glDisableVertexAttribArray(lnPos)
    }

    // ---------- پس‌زمینه ----------
    private fun drawBackground(frame: Frame) {
        if (frame.hasDisplayGeometryChanged()) {
            frame.transformCoordinates2d(
                Coordinates2d.OPENGL_NORMALIZED_DEVICE_COORDINATES, quadArr,
                Coordinates2d.TEXTURE_NORMALIZED, uvArr
            )
            uvBuf.position(0); uvBuf.put(uvArr); uvBuf.position(0)
        }
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthMask(false)
        GLES20.glUseProgram(bgProg)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, camTex)
        quad.position(0)
        GLES20.glVertexAttribPointer(bgPos, 2, GLES20.GL_FLOAT, false, 0, quad)
        GLES20.glVertexAttribPointer(bgUv, 2, GLES20.GL_FLOAT, false, 0, uvBuf)
        GLES20.glEnableVertexAttribArray(bgPos)
        GLES20.glEnableVertexAttribArray(bgUv)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(bgPos)
        GLES20.glDisableVertexAttribArray(bgUv)
        GLES20.glDepthMask(true)
    }

    // ---------- مدل ----------
    private fun uploadPending() {
        var tmp: IfcModel? = null
        var clr = false
        synchronized(this) { tmp = pendingModel; clr = clearModel; pendingModel = null; clearModel = false }
        val pm: IfcModel? = tmp
        if (pm == null && !clr) return
        freeGpu()
        fixed = false; markerAnchor = false; anchor?.detach(); anchor = null
        if (pm == null) return
        var te = 0
        var tt = 0
        for (m in pm.members) { te += m.edges.size; tt += m.tris.size }
        val allE = FloatArray(te)
        val allT = FloatArray(tt)
        val list = ArrayList<Gpu>(pm.members.size)
        var oe = 0
        var ot = 0
        for (m in pm.members) {
            System.arraycopy(m.edges, 0, allE, oe, m.edges.size)
            System.arraycopy(m.tris, 0, allT, ot, m.tris.size)
            list.add(Gpu(m, oe / 3, m.edges.size / 3, ot / 3, m.tris.size / 3))
            oe += m.edges.size
            ot += m.tris.size
        }
        bigE = vbo(allE); bigT = vbo(allT)
        totE = te / 3; totT = tt / 3
        qcCursor = 0
        gpu = list
    }

    private fun vbo(a: FloatArray): Int {
        if (a.isEmpty()) return 0
        val ids = IntArray(1)
        GLES20.glGenBuffers(1, ids, 0)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, ids[0])
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, a.size * 4, fb(a), GLES20.GL_STATIC_DRAW)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        return ids[0]
    }

    private fun freeGpu() {
        if (bigE != 0 || bigT != 0) GLES20.glDeleteBuffers(2, intArrayOf(bigE, bigT), 0)
        bigE = 0; bigT = 0; totE = 0; totT = 0
        gpu = emptyList()
    }

    private fun resetStates() { for (g in gpu) { g.red = false; g.dev = -1f } }

    private fun drawModel() {
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        GLES20.glUseProgram(lineProg)
        GLES20.glUniformMatrix4fv(lnMvp, 1, false, mvp, 0)
        GLES20.glEnableVertexAttribArray(lnPos)
        // صفحه‌ی برش (در مختصات خود مدل)
        val sz = ModelStore.model?.sizeM
        if (clipOn && sz != null) {
            val sign = if (clipFlip) -1f else 1f
            val ax = clipAxis.coerceIn(0, 2)
            GLES20.glUniform3f(lnAxis, if (ax == 0) sign else 0f, if (ax == 1) sign else 0f, if (ax == 2) sign else 0f)
            GLES20.glUniform1f(lnD, sign * clipPos * sz[ax])
            GLES20.glUniform1f(lnClipOn, 1f)
        } else {
            GLES20.glUniform1f(lnClipOn, 0f)
        }
        val fa = fillAlpha
        // ۱) همه‌ی قطعات آبی، با دو فراخوانی رسم (مثلث‌ها و خطوط)
        if (bigT != 0) {
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, bigT)
            GLES20.glVertexAttribPointer(lnPos, 3, GLES20.GL_FLOAT, false, 0, 0)
            GLES20.glUniform4f(lnColor, 0.15f, 0.45f, 0.95f, fa)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, totT)
        }
        if (bigE != 0) {
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, bigE)
            GLES20.glVertexAttribPointer(lnPos, 3, GLES20.GL_FLOAT, false, 0, 0)
            GLES20.glLineWidth(6f)
            GLES20.glUniform4f(lnColor, 0.15f, 0.55f, 1f, 0.28f)
            GLES20.glDrawArrays(GLES20.GL_LINES, 0, totE)
            GLES20.glLineWidth(2.5f)
            GLES20.glUniform4f(lnColor, 0.15f, 0.55f, 1f, 1f)
            GLES20.glDrawArrays(GLES20.GL_LINES, 0, totE)
        }
        // ۲) قطعات مغایر: فقط محدوده‌ی خودشان، قرمز و ضخیم‌تر روی آبی
        for (g in gpu) {
            if (!g.red) continue
            if (bigT != 0 && g.nT > 0) {
                GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, bigT)
                GLES20.glVertexAttribPointer(lnPos, 3, GLES20.GL_FLOAT, false, 0, 0)
                GLES20.glUniform4f(lnColor, 1f, 0.12f, 0.12f, minOf(0.85f, fa + 0.2f))
                GLES20.glDrawArrays(GLES20.GL_TRIANGLES, g.firstT, g.nT)
            }
            if (bigE != 0 && g.nE > 0) {
                GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, bigE)
                GLES20.glVertexAttribPointer(lnPos, 3, GLES20.GL_FLOAT, false, 0, 0)
                GLES20.glLineWidth(9f)
                GLES20.glUniform4f(lnColor, 1f, 0.12f, 0.12f, 0.40f)
                GLES20.glDrawArrays(GLES20.GL_LINES, g.firstE, g.nE)
                GLES20.glLineWidth(3.5f)
                GLES20.glUniform4f(lnColor, 1f, 0.12f, 0.12f, 1f)
                GLES20.glDrawArrays(GLES20.GL_LINES, g.firstE, g.nE)
            }
        }
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        GLES20.glDisableVertexAttribArray(lnPos)
        GLES20.glDisable(GLES20.GL_BLEND)
    }

    // ---------- کنترل QC با نقشه‌ی عمق ----------
    private fun runQc(frame: Frame) {
        val img = try { frame.acquireDepthImage16Bits() } catch (e: Exception) { return }
        try {
            val w = img.width; val h = img.height
            val plane = img.planes[0]
            val buf = plane.buffer.order(ByteOrder.nativeOrder())
            val rs = plane.rowStride; val ps = plane.pixelStride

            val inPts = floatArrayOf(0f, 0f, vw.toFloat(), 0f, 0f, vh.toFloat())
            val o = FloatArray(6)
            frame.transformCoordinates2d(Coordinates2d.VIEW, inPts, Coordinates2d.IMAGE_NORMALIZED, o)
            val dux = (o[2] - o[0]) / vw; val duy = (o[4] - o[0]) / vh
            val dvx = (o[3] - o[1]) / vw; val dvy = (o[5] - o[1]) / vh

            val rows = ArrayList<QcRow>()
            var ok = 0; var bad = 0; var worst = 0f; var worstName = ""; var noiseLimited = false
            val diffs = FloatArray(160)

            // در مدل‌های بزرگ در هر دور فقط حدود ۴۰۰ قطعه بررسی می‌شود و دورها می‌چرخند
            val total = gpu.size
            val step = max(1, total / 400)
            val startIdx = if (step > 1) qcCursor++ % step else 0
            var gi = startIdx
            while (gi < total) {
                val g = gpu[gi]
                gi += step
                val sm = g.m.samples
                var cnt = 0
                var zSum = 0f
                var i = 0
                while (i + 2 < sm.size && cnt < diffs.size) {
                    val x = sm[i]; val y = sm[i + 1]; val z = sm[i + 2]
                    i += 3
                    val cx = mvp[0] * x + mvp[4] * y + mvp[8] * z + mvp[12]
                    val cy = mvp[1] * x + mvp[5] * y + mvp[9] * z + mvp[13]
                    val cw = mvp[3] * x + mvp[7] * y + mvp[11] * z + mvp[15]
                    if (cw <= 0.05f) continue
                    val px = (cx / cw * 0.5f + 0.5f) * vw
                    val py = (1f - (cy / cw * 0.5f + 0.5f)) * vh
                    if (px < 0 || py < 0 || px >= vw || py >= vh) continue
                    val ez = mv[2] * x + mv[6] * y + mv[10] * z + mv[14]
                    val zMm = -ez * 1000f
                    if (zMm < 300f || zMm > 6000f) continue
                    val u = o[0] + px * dux + py * duy
                    val v = o[1] + px * dvx + py * dvy
                    val iu = (u * w).toInt().coerceIn(0, w - 1)
                    val iv = (v * h).toInt().coerceIn(0, h - 1)
                    val d = buf.getShort(iv * rs + iu * ps).toInt() and 0xFFFF
                    if (d == 0) continue
                    diffs[cnt++] = abs(d - zMm)
                    zSum += zMm
                }
                if (cnt < 6) { g.red = false; g.dev = -1f; continue }
                java.util.Arrays.sort(diffs, 0, cnt)
                val med = diffs[cnt / 2]
                if (med > 300f) { g.red = false; g.dev = -1f; continue }   // پشت مانع یا خارج از برد معتبر
                val userTol = if (g.m.isHole) tolHoleMm else tolMemberMm
                val noise = noisePct / 100f * (zSum / cnt)
                g.tol = max(userTol, noise)
                g.noiseLimited = noise > userTol
                g.dev = med
                g.red = med > g.tol
            }
            // جمع‌بندی روی همه‌ی قطعاتی که تا الان بررسی شده‌اند (نه فقط این دور)
            for (g in gpu) {
                if (g.dev < 0f) continue
                if (g.noiseLimited) noiseLimited = true
                if (g.red) { bad++; if (g.dev > worst) { worst = g.dev; worstName = g.m.name } } else ok++
                rows.add(QcRow(g.m.name, g.m.isHole, g.dev, g.tol, !g.red))
            }
            listener.onQc(QcResult(ok + bad, ok, bad, worst, worstName, noiseLimited, rows))
        } finally {
            img.close()
        }
    }

    // ---------- عکس QC ----------
    private fun maybeSnap() {
        if (!snapRequest) return
        snapRequest = false
        val buf = ByteBuffer.allocateDirect(vw * vh * 4).order(ByteOrder.nativeOrder())
        GLES20.glReadPixels(0, 0, vw, vh, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, buf)
        val px = IntArray(vw * vh)
        buf.asIntBuffer().get(px)
        // RGBA(byte) → ARGB ، و وارونه‌کردن عمودی
        val out = IntArray(vw * vh)
        for (y in 0 until vh) {
            for (x in 0 until vw) {
                val c = px[y * vw + x]
                val r = c and 0xFF
                val gg = (c shr 8) and 0xFF
                val b = (c shr 16) and 0xFF
                out[(vh - 1 - y) * vw + x] = (0xFF shl 24) or (r shl 16) or (gg shl 8) or b
            }
        }
        listener.onSnapshot(Bitmap.createBitmap(out, vw, vh, Bitmap.Config.ARGB_8888))
    }

    private fun program(vs: String, fs: String): Int {
        fun sh(type: Int, src: String): Int {
            val s = GLES20.glCreateShader(type)
            GLES20.glShaderSource(s, src)
            GLES20.glCompileShader(s)
            return s
        }
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, sh(GLES20.GL_VERTEX_SHADER, vs))
        GLES20.glAttachShader(p, sh(GLES20.GL_FRAGMENT_SHADER, fs))
        GLES20.glLinkProgram(p)
        return p
    }
}
