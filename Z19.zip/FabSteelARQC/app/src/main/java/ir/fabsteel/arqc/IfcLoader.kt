package ir.fabsteel.arqc

import android.app.Activity
import android.net.Uri
import java.io.BufferedInputStream
import java.io.InputStream

/** خواندن IFC یا خروجی ماکروی FabQC (تشخیص از روی ابتدای فایل). */
object IfcLoader {
    const val PDF_ERR = "PDF_3D"

    fun parse(ins: InputStream, progress: (String) -> Unit): IfcModel {
        val bin = BufferedInputStream(ins, 1 shl 16)
        bin.mark(16)
        val head = ByteArray(8)
        val n = bin.read(head)
        bin.reset()
        val s = if (n > 0) String(head, 0, n, Charsets.ISO_8859_1) else ""
        return when {
            s.startsWith("FABQC") -> FabQcParser.parse(bin)
            s.startsWith("%PDF") -> throw IllegalStateException(PDF_ERR)
            else -> try {
                IfcParser(progress).parse(bin)
            } catch (e: OutOfMemoryError) {
                throw IllegalStateException(TOO_BIG)
            }
        }
    }

    const val TOO_BIG = "فایل برای حافظه‌ی گوشی بیش از حد بزرگ است؛ فقط یک قطعه یا اسمبلی را از تکلا خروجی بگیرید"

    fun load(act: Activity, uri: Uri, progress: (String) -> Unit, done: (IfcModel?, String?) -> Unit) {
        Thread {
            try {
                val size = try {
                    act.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.SIZE), null, null, null)?.use { c ->
                        if (c.moveToFirst()) c.getLong(0) else -1L
                    } ?: -1L
                } catch (t: Throwable) { -1L }
                if (size > 60L * 1024 * 1024) throw IllegalStateException(TOO_BIG + " (${size / 1048576} MB)")
                val ins = act.contentResolver.openInputStream(uri) ?: throw IllegalStateException("فایل باز نشد")
                val m = ins.use { parse(it) { msg -> act.runOnUiThread { progress(msg) } } }
                ModelStore.model = m
                act.runOnUiThread { done(m, null) }
            } catch (t: Throwable) {
                act.runOnUiThread { done(null, t.message ?: t.javaClass.simpleName) }
            }
        }.start()
    }
}
