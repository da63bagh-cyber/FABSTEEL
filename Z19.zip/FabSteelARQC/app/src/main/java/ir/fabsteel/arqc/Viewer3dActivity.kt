package ir.fabsteel.arqc

import android.content.Context
import android.graphics.*
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.*

/** نمای سه‌بعدی ساده‌ی مدل IFC با چرخش، زوم و جابه‌جایی (رسم خطوط لبه روی Canvas). */
class ModelView(c: Context) : View(c) {
    private var segs = FloatArray(0)
    private var cx = 0f; private var cy = 0f; private var cz = 0f; private var radius = 1f
    var yaw = 0.7f; var pitch = 0.5f; private var zoom = 1f
    private var panX = 0f; private var panY = 0f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF5EC8FF.toInt(); strokeWidth = 1.6f; style = Paint.Style.STROKE
    }
    private val holePaint = Paint(paint).apply { color = 0xFFFFC107.toInt() }
    private var holeSegs = FloatArray(0)
    private var lx = 0f; private var ly = 0f

    private val sd = ScaleGestureDetector(c, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean { zoom = (zoom * d.scaleFactor).coerceIn(0.1f, 60f); invalidate(); return true }
    })

    fun setModel(m: IfcModel?) {
        if (m == null) { segs = FloatArray(0); holeSegs = FloatArray(0); invalidate(); return }
        val a = ArrayList<Float>(); val h = ArrayList<Float>()
        var total = 0L
        for (mb in m.members) total += mb.edges.size
        val step = max(1, (total / 6 / 150000).toInt()) // حداکثر حدود ۱۵۰ هزار پاره‌خط
        var k = 0
        for (mb in m.members) {
            val dst = if (mb.isHole) h else a
            var i = 0
            while (i + 5 < mb.edges.size) {
                if (k++ % step == 0) for (j in 0..5) dst.add(mb.edges[i + j])
                i += 6
            }
        }
        segs = a.toFloatArray(); holeSegs = h.toFloatArray()
        val s = m.sizeM
        cx = s[0] / 2; cy = s[1] / 2; cz = s[2] / 2
        radius = max(0.001f, sqrt(s[0] * s[0] + s[1] * s[1] + s[2] * s[2]) / 2)
        fit(); invalidate()
    }
    fun fit() { zoom = 1f; panX = 0f; panY = 0f; invalidate() }
    fun iso() { yaw = 0.7f; pitch = 0.5f; fit() }

    override fun onDraw(c: Canvas) {
        c.drawColor(0xFF0A1226.toInt())
        val sc = min(width, height) / 2f / radius * zoom * 0.9f
        val cyw = cos(yaw); val syw = sin(yaw); val cp = cos(pitch); val sp = sin(pitch)
        val ox = width / 2f + panX; val oy = height / 2f + panY
        fun draw(arr: FloatArray, p: Paint) {
            if (arr.isEmpty()) return
            val out = FloatArray(arr.size / 3 * 2)
            var i = 0; var o = 0
            while (i + 2 < arr.size) {
                val x = arr[i] - cx; val y = arr[i + 1] - cy; val z = arr[i + 2] - cz
                val x1 = x * cyw + z * syw; val z1 = -x * syw + z * cyw
                val y2 = y * cp - z1 * sp
                out[o++] = ox + x1 * sc; out[o++] = oy - y2 * sc
                i += 3
            }
            c.drawLines(out, p)
        }
        draw(segs, paint); draw(holeSegs, holePaint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        sd.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_UP -> { lx = e.x; ly = e.y }
            MotionEvent.ACTION_MOVE -> if (!sd.isInProgress) {
                val dx = e.x - lx; val dy = e.y - ly; lx = e.x; ly = e.y
                if (e.pointerCount >= 2) { panX += dx; panY += dy }
                else { yaw += dx * 0.01f; pitch = (pitch + dy * 0.01f).coerceIn(-1.5f, 1.5f) }
                invalidate()
            } else { lx = e.x; ly = e.y }
        }
        return true
    }
}

class Viewer3dActivity : AppCompatActivity() {
    private lateinit var mv: ModelView
    private lateinit var status: TextView
    private val pick = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            status.text = "در حال خواندن فایل…"
            IfcLoader.load(this, uri, { status.text = it }) { m, err ->
                if (m != null) { mv.setModel(m); status.text = "${m.members.size} قطعه" }
                else if (err == IfcLoader.PDF_ERR) {
                    status.text = "3D PDF پشتیبانی نمی‌شود"
                    androidx.appcompat.app.AlertDialog.Builder(this)
                        .setTitle("3D PDF")
                        .setMessage("خواندن مدل داخل 3D PDF هنوز پشتیبانی نمی‌شود (فرمت U3D فشرده است).\n\nاز تکلا با ماکروی FabQC خروجی بگیرید (فایل .fabqc) یا از IFC استفاده کنید؛ هر دو اینجا به‌صورت سه‌بعدی باز می‌شوند.")
                        .setPositiveButton("OK", null).show()
                }
                else status.text = "خطا: $err"
            }
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        mv = ModelView(this)
        root.addView(mv, LinearLayout.LayoutParams(-1, 0, 1f))
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(8, 8, 8, 8); setBackgroundColor(0xFF0A1226.toInt()) }
        fun btn(t: String, a: () -> Unit) = Button(this).apply { text = t; textSize = 18f; setOnClickListener { a() } }
            .also { bar.addView(it, LinearLayout.LayoutParams(0, -2, 1f)) }
        btn("3D PDF UPLOAD") { pick.launch(arrayOf("*/*")) }
        btn("Fit") { mv.fit() }
        btn("Iso") { mv.iso() }
        status = TextView(this).apply { setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER }
        bar.addView(status, LinearLayout.LayoutParams(0, -2, 1.3f))
        btn("⌂ منو") { finish() }
        root.addView(bar)
        setContentView(root)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        ModelStore.model?.let { mv.setModel(it); status.text = "${it.members.size} قطعه" }
    }
}
