plugins {
    kotlin("jvm") version "1.9.24"
}

repositories {
    mavenCentral()
}

dependencies {
    implementation("com.google.zxing:core:3.5.3")
}

tasks.jar {
    archiveFileName.set("fabsteel-qcar.jar")
    manifest { attributes["Main-Class"] = "ir.fabsteel.arqc.MainKt" }
    duplicatesStrategy = DuplicatesStrategy.EXCLUDE
    exclude("META-INF/*.SF", "META-INF/*.DSA", "META-INF/*.RSA")
    from(configurations.runtimeClasspath.get().map { if (it.isDirectory) it else zipTree(it) })
}
