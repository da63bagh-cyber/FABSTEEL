package ir.fabsteel.arqc

import java.io.ByteArrayOutputStream
import java.util.Locale

/** یک برچسب: هولوگرام (QR) + کد قطعه + برند + نام + پرچم. matrix: ماژول‌های QR (true = سیاه). */
class Label(val code: String, val faceTxt: String, val id: String, val matrix: Array<BooleanArray>, val codeMm: Float)

/** نویسنده‌ی ساده‌ی PDF (A4، برداری): چند برچسب در شبکه، با اندازه‌ی واقعی برای چاپ و برش. */
object PdfMarker {
    const val STRIP_MM = 26f                       // ارتفاع نوار نوشته زیر هولوگرام
    private const val PT = 72f / 25.4f
    private const val PW = 595.276f; private const val PH = 841.89f
    private const val GAP = 4f; private const val MARGIN = 10f

    private fun f(v: Float) = String.format(Locale.US, "%.3f", v)
    private fun mm(v: Float) = v * PT
    private fun esc(s: String) = s.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
        .map { if (it.code in 32..126) it.toString() else "?" }.joinToString("")

    private fun grid(codeMm: Float): IntArray {
        val w = codeMm * 1.2f; val h = codeMm * 1.2f + STRIP_MM
        val cols = ((PW / PT - 2 * MARGIN + GAP) / (w + GAP)).toInt().coerceAtLeast(1)
        val rows = (((PH / PT) - MARGIN - 14f + GAP) / (h + GAP)).toInt().coerceAtLeast(1)
        return intArrayOf(cols, rows)
    }

    private fun flag(sb: StringBuilder, x: Float, y: Float, w: Float, h: Float) {
        sb.append("0.137 0.624 0.251 rg ${f(x)} ${f(y + 2 * h / 3)} ${f(w)} ${f(h / 3)} re f\n")
        sb.append("1 g ${f(x)} ${f(y + h / 3)} ${f(w)} ${f(h / 3)} re f\n")
        sb.append("0.855 0 0 rg ${f(x)} ${f(y)} ${f(w)} ${f(h / 3)} re f\n")
        sb.append("0.3 w 0.5 G ${f(x)} ${f(y)} ${f(w)} ${f(h)} re S\n")
        val ex = x + w / 2; val ey = y + h / 2; val u = h * 0.15f
        sb.append("0.855 0 0 RG ${f(0.45f * u + 0.3f)} w 1 J\n")
        sb.append("${f(ex - 0.35f * u)} ${f(ey + u)} m ${f(ex - 1.4f * u)} ${f(ey + 0.6f * u)} ${f(ex - 1.4f * u)} ${f(ey - 0.6f * u)} ${f(ex - 0.35f * u)} ${f(ey - u)} c S\n")
        sb.append("${f(ex + 0.35f * u)} ${f(ey + u)} m ${f(ex + 1.4f * u)} ${f(ey + 0.6f * u)} ${f(ex + 1.4f * u)} ${f(ey - 0.6f * u)} ${f(ex + 0.35f * u)} ${f(ey - u)} c S\n")
        sb.append("${f(ex)} ${f(ey - 1.1f * u)} m ${f(ex)} ${f(ey + 1.1f * u)} l S\n")
    }

    private fun page(labels: List<Label>, cols: Int, rows: Int): String {
        val sb = StringBuilder()
        fun text(x: Float, y: Float, size: Float, bold: Boolean, t: String) {
            sb.append("0 g BT /${if (bold) "F2" else "F1"} ${f(size)} Tf ${f(x)} ${f(y)} Td (${esc(t)}) Tj ET\n")
        }
        for ((i, lb) in labels.withIndex()) {
            val c = i % cols; val r = i / cols
            val S = lb.codeMm
            val W = S * 1.2f; val H = S * 1.2f + STRIP_MM
            val lx = mm(MARGIN + c * (W + GAP))
            val ly = PH - mm(MARGIN + (r + 1) * H + r * GAP)
            // خط برش
            sb.append("0.4 w 0.55 G ${f(lx)} ${f(ly)} ${f(mm(W))} ${f(mm(H))} re S\n")
            // هولوگرام
            val n = lb.matrix.size
            val modPt = mm(S) / n
            val qx = lx + mm(0.1f * S); val qy = ly + mm(STRIP_MM) + mm(0.1f * S)
            sb.append("0 g\n")
            for (row in 0 until n) {
                var cc = 0
                while (cc < n) {
                    if (lb.matrix[row][cc]) {
                        var e = cc
                        while (e + 1 < n && lb.matrix[row][e + 1]) e++
                        sb.append("${f(qx + cc * modPt)} ${f(qy + (n - 1 - row) * modPt)} ${f((e - cc + 1) * modPt)} ${f(modPt)} re\n")
                        cc = e + 1
                    } else cc++
                }
            }
            sb.append("f\n")
            // نشان گوشه‌ی چسباندن (پایین-چپ برچسب)
            sb.append("0.9 0.1 0.1 rg ${f(lx)} ${f(ly)} m ${f(lx + mm(4f))} ${f(ly)} l ${f(lx)} ${f(ly + mm(4f))} l f\n")
            // نوشته‌ها
            val maxW = mm(W - 4f)
            val code = lb.code
            val fs = minOf(13f, maxW / (code.length.coerceAtLeast(1) * 0.6f)).coerceAtLeast(6f)
            text(lx + mm(2f), ly + mm(STRIP_MM - 7.5f), fs, true, code)
            text(lx + mm(2f), ly + mm(STRIP_MM - 13f), 9f, true, "FabSteel QC AR")
            text(lx + mm(2f), ly + mm(STRIP_MM - 17.5f), 8f, false, "Eng Davod Bagheri")
            text(lx + mm(2f), ly + mm(2.2f), 5.5f, false, "${lb.faceTxt} | ID ${lb.id} | ${S.toInt()} mm")
            flag(sb, lx + mm(W - 2f - 13f), ly + mm(5.5f), mm(13f), mm(8.7f))
        }
        // پاورقی
        val cm = labels.firstOrNull()?.codeMm ?: 50f
        text(mm(MARGIN), mm(7f), 8f, false, "Print at 100% / Actual size (NOT Fit to page). All dimensions in mm. Cut along grey lines. Glue: red corner = bottom-left corner of the part face.")
        val bx = mm(MARGIN); val by = mm(11f)
        sb.append("0 g 0 G 0.8 w ${f(bx)} ${f(by)} m ${f(bx + mm(cm))} ${f(by)} l S 0.8 w ${f(bx)} ${f(by - 2)} m ${f(bx)} ${f(by + 2)} l S ${f(bx + mm(cm))} ${f(by - 2)} m ${f(bx + mm(cm))} ${f(by + 2)} l S\n")
        text(bx + mm(cm) + 6f, by - 3f, 8f, false, "this bar = ${cm.toInt()} mm")
        return sb.toString()
    }

    fun build(labels: List<Label>): ByteArray {
        val cm = labels.first().codeMm
        val (cols, rows) = grid(cm).let { it[0] to it[1] }
        val per = cols * rows
        val chunks = labels.chunked(per)
        val out = ByteArrayOutputStream()
        val offs = ArrayList<Int>()
        fun w(s: String) = out.write(s.toByteArray(Charsets.ISO_8859_1))
        fun obj(body: String) { offs.add(out.size()); w("${offs.size} 0 obj\n$body\nendobj\n") }
        w("%PDF-1.4\n")
        val kids = chunks.indices.joinToString(" ") { "${5 + it * 2} 0 R" }
        obj("<< /Type /Catalog /Pages 2 0 R >>")
        obj("<< /Type /Pages /Kids [$kids] /Count ${chunks.size} >>")
        obj("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>")
        obj("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>")
        for ((i, ch) in chunks.withIndex()) {
            val c = page(ch, cols, rows)
            obj("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${f(PW)} ${f(PH)}] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents ${6 + i * 2} 0 R >>")
            obj("<< /Length ${c.length} >>\nstream\n$c\nendstream")
        }
        val xr = out.size()
        w("xref\n0 ${offs.size + 1}\n0000000000 65535 f \n")
        for (o in offs) w(String.format(Locale.US, "%010d 00000 n \n", o))
        w("trailer\n<< /Size ${offs.size + 1} /Root 1 0 R >>\nstartxref\n$xr\n%%EOF\n")
        return out.toByteArray()
    }
}
