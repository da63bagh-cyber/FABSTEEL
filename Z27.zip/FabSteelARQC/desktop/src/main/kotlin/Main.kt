package ir.fabsteel.arqc

import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import java.awt.BasicStroke
import java.awt.BorderLayout
import java.awt.Color
import java.awt.Dimension
import java.awt.FlowLayout
import java.awt.Font
import java.awt.Graphics
import java.awt.Graphics2D
import java.awt.RenderingHints
import java.awt.event.MouseAdapter
import java.awt.event.MouseEvent
import java.awt.event.MouseWheelEvent
import java.io.BufferedInputStream
import java.io.File
import java.util.UUID
import javax.swing.BorderFactory
import javax.swing.JButton
import javax.swing.JCheckBox
import javax.swing.JComboBox
import javax.swing.JScrollPane
import javax.swing.BoxLayout
import javax.swing.JFileChooser
import javax.swing.JFrame
import javax.swing.JLabel
import javax.swing.JOptionPane
import javax.swing.JPanel
import javax.swing.JTextField
import javax.swing.SwingUtilities
import javax.swing.UIManager
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

val FACE_EN = arrayOf("FRONT (+Z)", "BACK (-Z)", "RIGHT (+X)", "LEFT (-X)", "TOP (+Y)", "BOTTOM (-Y)")

/** بارگذاری IFC، .fabqc یا PDF سه‌بعدی */
fun loadAny(f: File, progress: (String) -> Unit): IfcModel {
    BufferedInputStream(f.inputStream(), 1 shl 16).use { bin ->
        bin.mark(16)
        val head = ByteArray(8)
        val n = bin.read(head)
        bin.reset()
        val s = if (n > 0) String(head, 0, n, Charsets.ISO_8859_1) else ""
        return when {
            s.startsWith("FABQC") -> FabQcParser.parse(bin)
            s.startsWith("%PDF") -> {
                val u = U3dReader.extractFromPdf(bin.readBytes())
                if (u.isEmpty()) throw IllegalStateException("This PDF has no 3D (U3D) model")
                U3dReader.build(u)
            }
            n >= 2 && head[0] == 0x1f.toByte() && head[1] == 0x8b.toByte() -> Qcar.read(bin).model
            else -> IfcParser(progress).parse(bin)
        }
    }
}

fun qrMatrix(text: String): Array<BooleanArray> {
    val hints = mapOf<EncodeHintType, Any>(EncodeHintType.MARGIN to 0, EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M)
    val bm = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, 0, 0, hints)
    return Array(bm.height) { y -> BooleanArray(bm.width) { x -> bm.get(x, y) } }
}

/** پیش‌نمایش سه‌بعدی ساده (سیم‌کشی) با چرخش و زوم + برچسب وجه‌ها */
class Preview : JPanel() {
    var model: IfcModel? = null
        set(v) { field = v; repaint() }
    private var yaw = 0.6f; private var pitch = 0.35f; private var zoom = 1f
    private var lx = 0; private var ly = 0
    var selected = BooleanArray(6)

    init {
        background = Color(0x0A, 0x12, 0x26)
        preferredSize = Dimension(520, 420)
        addMouseListener(object : MouseAdapter() { override fun mousePressed(e: MouseEvent) { lx = e.x; ly = e.y } })
        addMouseMotionListener(object : MouseAdapter() {
            override fun mouseDragged(e: MouseEvent) {
                yaw += (e.x - lx) * 0.01f; pitch = (pitch + (e.y - ly) * 0.01f).coerceIn(-1.5f, 1.5f)
                lx = e.x; ly = e.y; repaint()
            }
        })
        addMouseWheelListener { e: MouseWheelEvent -> zoom = (zoom * (if (e.wheelRotation < 0) 1.1f else 0.9f)).coerceIn(0.2f, 10f); repaint() }
    }

    override fun paintComponent(g0: Graphics) {
        super.paintComponent(g0)
        val g = g0 as Graphics2D
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON)
        val m = model
        if (m == null) {
            g.color = Color.WHITE; g.font = Font("Segoe UI", Font.PLAIN, 14)
            g.drawString("Open an IFC file / فایل IFC را باز کنید", 20, 30); return
        }
        val s = m.sizeM
        val cx = s[0] / 2; val cy = s[1] / 2; val cz = s[2] / 2
        val rad = max(0.001f, sqrt(s[0] * s[0] + s[1] * s[1] + s[2] * s[2]) / 2)
        val sc = min(width, height) / 2f / rad * zoom * 0.8f
        val cyw = cos(yaw); val syw = sin(yaw); val cp = cos(pitch); val sp = sin(pitch)
        fun pr(x: Float, y: Float, z: Float): FloatArray {
            val a = x - cx; val b = y - cy; val c = z - cz
            val x1 = a * cyw + c * syw; val z1 = -a * syw + c * cyw
            val y2 = b * cp - z1 * sp
            return floatArrayOf(width / 2f + x1 * sc, height / 2f - y2 * sc)
        }
        g.stroke = BasicStroke(1f)
        for (mb in m.members) {
            g.color = if (mb.isHole) Color(0xFF, 0xC1, 0x07) else Color(0x5E, 0xC8, 0xFF)
            var i = 0
            val e = mb.edges
            while (i + 5 < e.size) {
                val p = pr(e[i], e[i + 1], e[i + 2]); val q = pr(e[i + 3], e[i + 4], e[i + 5])
                g.drawLine(p[0].toInt(), p[1].toInt(), q[0].toInt(), q[1].toInt())
                i += 6
            }
        }
        // مرکز وجه‌ها
        val ctr = arrayOf(
            floatArrayOf(s[0] / 2, s[1] / 2, s[2]), floatArrayOf(s[0] / 2, s[1] / 2, 0f),
            floatArrayOf(s[0], s[1] / 2, s[2] / 2), floatArrayOf(0f, s[1] / 2, s[2] / 2),
            floatArrayOf(s[0] / 2, s[1], s[2] / 2), floatArrayOf(s[0] / 2, 0f, s[2] / 2))
        g.font = Font("Segoe UI", Font.BOLD, 12)
        for (i in 0..5) {
            val p = pr(ctr[i][0], ctr[i][1], ctr[i][2])
            g.color = if (selected[i]) Color(0x39, 0xE5, 0x8D) else Color(0xAA, 0xAA, 0xAA)
            g.drawString((if (selected[i]) "■ " else "□ ") + FACE_EN[i], p[0].toInt() - 30, p[1].toInt())
        }
    }
}

class Entry(val file: File, val model: IfcModel, val code: JTextField, val face: JComboBox<String>, val row: JPanel)

fun main() {
    try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()) } catch (_: Throwable) {}
    SwingUtilities.invokeLater {
        val fr = JFrame("FabSteel QC AR — Hologram maker (Eng Davod Bagheri)")
        fr.defaultCloseOperation = JFrame.EXIT_ON_CLOSE
        val pv = Preview()
        val entries = ArrayList<Entry>()
        val list = JPanel(); list.layout = BoxLayout(list, BoxLayout.Y_AXIS)
        val scroll = JScrollPane(list); scroll.preferredSize = Dimension(430, 300)
        val size = JTextField("50", 4)
        val info = JLabel(" ")

        fun show(e: Entry?) {
            pv.model = e?.model
            pv.selected = BooleanArray(6).also { a -> if (e != null) a[e.face.selectedIndex] = true }
            pv.repaint()
        }

        fun addRow(f: File, m: IfcModel) {
            val code = JTextField(f.nameWithoutExtension, 14)
            val face = JComboBox(FACE_EN)
            val row = JPanel(FlowLayout(FlowLayout.LEFT))
            val rm = JButton("×")
            row.add(JLabel("Code:")); row.add(code); row.add(JLabel("Face:")); row.add(face); row.add(rm)
            val e = Entry(f, m, code, face, row)
            entries.add(e); list.add(row); list.revalidate(); list.repaint()
            face.addActionListener { show(e) }
            row.addMouseListener(object : MouseAdapter() { override fun mousePressed(ev: MouseEvent) { show(e) } })
            code.addFocusListener(object : java.awt.event.FocusAdapter() { override fun focusGained(ev: java.awt.event.FocusEvent) { show(e) } })
            rm.addActionListener { entries.remove(e); list.remove(row); list.revalidate(); list.repaint(); show(entries.lastOrNull()) }
            show(e)
        }

        val open = JButton("1) Add IFC file(s) / افزودن IFC")
        open.addActionListener {
            val fc = JFileChooser(); fc.isMultiSelectionEnabled = true
            if (fc.showOpenDialog(fr) == JFileChooser.APPROVE_OPTION) {
                val files = fc.selectedFiles.toList()
                Thread {
                    for ((k, f) in files.withIndex()) {
                        SwingUtilities.invokeLater { info.text = "Reading ${k + 1}/${files.size}: ${f.name} …" }
                        try {
                            val m = loadAny(f) { }
                            SwingUtilities.invokeLater {
                                addRow(f, m)
                                val s = m.sizeM
                                info.text = "${f.name}: ${m.members.size} members | %.0f × %.0f × %.0f mm".format(s[0] * 1000, s[2] * 1000, s[1] * 1000)
                            }
                        } catch (t: Throwable) {
                            SwingUtilities.invokeLater { JOptionPane.showMessageDialog(fr, "${f.name}\nError: ${t.message ?: t.javaClass.simpleName}", "FabSteel", JOptionPane.ERROR_MESSAGE) }
                        }
                    }
                }.start()
            }
        }

        val export = JButton("2) Export .qcar files + holograms PDF / خروجی")
        export.addActionListener {
            if (entries.isEmpty()) { JOptionPane.showMessageDialog(fr, "Add IFC file(s) first / اول IFC را اضافه کنید"); return@addActionListener }
            val mm = size.text.replace(',', '.').trim().toFloatOrNull()
            if (mm == null || mm < 30f || mm > 90f) { JOptionPane.showMessageDialog(fr, "Hologram size must be 30–90 mm (default 50)"); return@addActionListener }
            val fc = JFileChooser(); fc.fileSelectionMode = JFileChooser.DIRECTORIES_ONLY
            fc.dialogTitle = "Output folder / پوشه‌ی خروجی"
            if (fc.showSaveDialog(fr) != JFileChooser.APPROVE_OPTION) return@addActionListener
            val dir = fc.selectedFile
            try {
                val mmTxt = if (mm == mm.toInt().toFloat()) mm.toInt().toString() else mm.toString()
                val labels = ArrayList<Label>()
                val used = HashSet<String>()
                val written = StringBuilder()
                for (e in entries) {
                    var nm = e.code.text.trim().ifEmpty { e.file.nameWithoutExtension }.replace(Regex("[^A-Za-z0-9_\\-.]"), "_")
                    if (!used.add(nm)) { var k = 2; while (!used.add("${nm}_$k")) k++; nm = "${nm}_$k" }
                    val id = UUID.randomUUID().toString().replace("-", "").substring(0, 8)
                    val face = e.face.selectedIndex
                    File(dir, "$nm.qcar").outputStream().use { Qcar.write(e.model, id, nm, it) }
                    labels.add(Label(nm, FACE_EN[face], id, qrMatrix("FQ2|$id|$face|$mmTxt|${PdfMarker.STRIP_MM.toInt()}"), mm))
                    written.append(nm).append(".qcar\n")
                }
                val pf = File(dir, "Holograms_${System.currentTimeMillis() / 1000}.pdf")
                pf.writeBytes(PdfMarker.build(labels))
                JOptionPane.showMessageDialog(fr, "Done / انجام شد (${labels.size}):\n${dir.absolutePath}\n\n$written\n${pf.name} → print at 100%, cut, glue\n.qcar → send to phone, QC AR → Upload (once)")
            } catch (t: Throwable) {
                JOptionPane.showMessageDialog(fr, "Error: ${t.message ?: t.javaClass.simpleName}", "FabSteel", JOptionPane.ERROR_MESSAGE)
            }
        }

        val top = JPanel(FlowLayout(FlowLayout.LEFT)); top.add(open); top.add(info)
        val side = JPanel(); side.layout = BoxLayout(side, BoxLayout.Y_AXIS)
        side.border = BorderFactory.createEmptyBorder(8, 8, 8, 8)
        val sz = JPanel(FlowLayout(FlowLayout.LEFT)); sz.add(JLabel("Hologram size (mm):")); sz.add(size)
        side.add(sz)
        side.add(JLabel("Each row = one part (code + face where the label is glued)"))
        side.add(scroll)
        side.add(JLabel(" ")); side.add(export)
        fr.layout = BorderLayout()
        fr.add(top, BorderLayout.NORTH); fr.add(pv, BorderLayout.CENTER); fr.add(side, BorderLayout.EAST)
        fr.pack(); fr.setLocationRelativeTo(null); fr.isVisible = true
    }
}
