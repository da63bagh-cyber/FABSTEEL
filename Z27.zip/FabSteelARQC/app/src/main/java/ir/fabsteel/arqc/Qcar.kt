package ir.fabsteel.arqc

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream

class QcarData(val model: IfcModel, val id: String, val name: String)

/** فرمت .qcar (FabSteel QC AR): مدل آماده برای گوشی. gzip( "QCAR", نسخه، id، نام، ابعاد، اعضا ) */
object Qcar {
    private const val MAGIC = "QCAR"

    fun write(model: IfcModel, id: String, name: String, out: OutputStream) {
        DataOutputStream(BufferedOutputStream(GZIPOutputStream(out, 1 shl 16), 1 shl 16)).use { d ->
            d.writeBytes(MAGIC)
            d.writeInt(1)
            d.writeUTF(id)
            d.writeUTF(name)
            for (v in model.sizeM) d.writeFloat(v)
            d.writeInt(model.members.size)
            for (m in model.members) {
                d.writeUTF(m.name)
                d.writeBoolean(m.isHole)
                wf(d, m.edges); wf(d, m.tris); wf(d, m.samples)
            }
        }
    }

    private fun wf(d: DataOutputStream, a: FloatArray) {
        d.writeInt(a.size)
        for (v in a) d.writeFloat(v)
    }

    private fun rf(d: DataInputStream): FloatArray {
        val n = d.readInt()
        if (n < 0 || n > 200_000_000) throw IllegalStateException("فایل qcar خراب است")
        return FloatArray(n) { d.readFloat() }
    }

    fun read(input: InputStream): QcarData {
        DataInputStream(BufferedInputStream(GZIPInputStream(input, 1 shl 16), 1 shl 16)).use { d ->
            val mg = ByteArray(4)
            d.readFully(mg)
            if (String(mg, Charsets.ISO_8859_1) != MAGIC) throw IllegalStateException("این فایل qcar نیست")
            val ver = d.readInt()
            if (ver != 1) throw IllegalStateException("نسخه‌ی فایل qcar پشتیبانی نمی‌شود")
            val id = d.readUTF(); val name = d.readUTF()
            val size = floatArrayOf(d.readFloat(), d.readFloat(), d.readFloat())
            val n = d.readInt()
            val list = ArrayList<Member>(n)
            for (i in 0 until n) {
                val nm = d.readUTF(); val hole = d.readBoolean()
                val e = rf(d); val t = rf(d); val s = rf(d)
                list.add(Member(nm, hole, e, t, s))
            }
            return QcarData(IfcModel(list, size), id, name)
        }
    }
}
