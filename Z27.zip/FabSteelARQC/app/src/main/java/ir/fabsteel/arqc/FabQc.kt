package ir.fabsteel.arqc

import java.io.InputStream

/**
 * خواندن خروجی ماکروی تکلا (FabQcExport.cs). قالب متنی:
 *   FABQC 1 mm
 *   P<TAB>نام قطعه<TAB>پروفیل
 *   E<TAB>x1 y1 z1 x2 y2 z2     (لبه)
 *   H<TAB>x1 y1 z1 x2 y2 z2     (لبه‌ی سوراخ)
 * مختصات تکلا بر حسب mm و Z بالا؛ به دستگاه AR (Y بالا، متر) و گوشه‌ی مینیمم تبدیل می‌شود.
 */
object FabQcParser {
    private class Part(val name: String) {
        val e = FList(); val h = FList()
    }

    fun parse(input: InputStream): IfcModel {
        val parts = ArrayList<Part>()
        var cur: Part? = null
        val mn = floatArrayOf(Float.MAX_VALUE, Float.MAX_VALUE, Float.MAX_VALUE)
        val mx = floatArrayOf(-Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE)
        input.bufferedReader(Charsets.UTF_8).useLines { lines ->
            for (line in lines) {
                if (line.length < 2) continue
                val c = line[0]
                if (c == 'P') {
                    val f = line.split('\t')
                    val nm = if (f.size > 2) f[1] + " " + f[2] else if (f.size > 1) f[1] else "part"
                    cur = Part(nm.trim()); parts.add(cur!!)
                } else if (c == 'E' || c == 'H') {
                    val p = cur ?: continue
                    val tab = line.indexOf('\t')
                    if (tab < 0) continue
                    val t = line.substring(tab + 1).trim().split(' ')
                    if (t.size < 6) continue
                    val v = FloatArray(6)
                    var ok = true
                    for (i in 0..5) { val d = t[i].toFloatOrNull(); if (d == null) { ok = false; break }; v[i] = d }
                    if (!ok) continue
                    val dst = if (c == 'H') p.h else p.e
                    for (k in 0..1) {
                        // تکلا (x, y, z-بالا) -> AR (x, z, -y)، mm -> m
                        val x = v[k * 3] * 0.001f
                        val y = v[k * 3 + 2] * 0.001f
                        val z = -v[k * 3 + 1] * 0.001f
                        if (x < mn[0]) mn[0] = x; if (y < mn[1]) mn[1] = y; if (z < mn[2]) mn[2] = z
                        if (x > mx[0]) mx[0] = x; if (y > mx[1]) mx[1] = y; if (z > mx[2]) mx[2] = z
                        dst.add(x, y, z)
                    }
                }
            }
        }
        if (parts.isEmpty() || mn[0] == Float.MAX_VALUE) throw IllegalStateException("فایل FabQC خالی است")
        val members = ArrayList<Member>()
        for (p in parts) {
            if (p.e.n > 0) members.add(mk(p.name, false, p.e.toArray(), mn))
            if (p.h.n > 0) members.add(mk(p.name + " (holes)", true, p.h.toArray(), mn))
        }
        return IfcModel(members, floatArrayOf(mx[0] - mn[0], mx[1] - mn[1], mx[2] - mn[2]))
    }

    private fun mk(name: String, hole: Boolean, edges: FloatArray, mn: FloatArray): Member {
        var i = 0
        while (i < edges.size) { edges[i] -= mn[0]; edges[i + 1] -= mn[1]; edges[i + 2] -= mn[2]; i += 3 }
        // نقاط نمونه: وسط هر پاره‌خط (حداکثر ~400 نقطه)
        val nSeg = edges.size / 6
        val st = maxOf(1, nSeg / 400)
        val s = FList()
        var q = 0
        while (q < nSeg) {
            s.add((edges[q * 6] + edges[q * 6 + 3]) / 2, (edges[q * 6 + 1] + edges[q * 6 + 4]) / 2, (edges[q * 6 + 2] + edges[q * 6 + 5]) / 2)
            q += st
        }
        return Member(name, hole, edges, FloatArray(0), s.toArray())
    }
}
