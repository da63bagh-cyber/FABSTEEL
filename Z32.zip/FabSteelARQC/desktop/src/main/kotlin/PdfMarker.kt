package ir.fabsteel.arqc

import java.awt.Font
import java.awt.GraphicsEnvironment
import java.awt.font.FontRenderContext
import java.awt.font.TextLayout
import java.awt.geom.PathIterator
import java.io.ByteArrayOutputStream
import java.util.zip.Deflater
import javax.imageio.ImageIO
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** یک برچسب: هولوگرام (QR) + کد قطعه + برند + نام + پرچم. matrix: ماژول‌های QR (true = سیاه). */
class Label(
    val code: String, val face: Int, val pos: Int, val id: String, val matrix: Array<BooleanArray>, val codeMm: Float,
    val size: FloatArray, val boxes: List<FloatArray>   // size: ابعاد جعبه (متر، دستگاه مدل) ؛ boxes: جعبه‌ی هر عضو [x0,y0,z0,x1,y1,z1]
)

/** نویسنده‌ی ساده‌ی PDF (A4، برداری): چند برچسب در شبکه، با اندازه‌ی واقعی برای چاپ و برش. */
object PdfMarker {
    const val STRIP_MM = 60f                       // ارتفاع نوار نوشته زیر هولوگرام
    private const val PT = 72f / 25.4f
    private const val PW = 595.276f; private const val PH = 841.89f
    private const val GAP = 4f; private const val MARGIN = 10f

    private fun f(v: Float) = String.format(Locale.US, "%.3f", v)
    private fun mm(v: Float) = v * PT
    private fun esc(s: String) = s.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
        .map { if (it.code in 32..126) it.toString() else "?" }.joinToString("")


    // ---------- متن فارسی: خطوط حروف با AWT به مسیر برداری PDF تبدیل می‌شود (بدون نیاز به فونت داخل PDF) ----------
    private val faFont: Font by lazy {
        val names = GraphicsEnvironment.getLocalGraphicsEnvironment().availableFontFamilyNames.toSet()
        val pick = listOf("Tahoma", "Segoe UI", "Arial", "Times New Roman", "DejaVu Sans", "FreeSerif", "Noto Sans Arabic").firstOrNull { it in names && Font(it, Font.PLAIN, 20).canDisplay('پ') }
        Font(pick ?: "Dialog", Font.PLAIN, 100)
    }

    /** متن راست‌به‌چپ؛ لبه‌ی راست متن در x (به پوینت)، خط پایه در y */
    private fun fa(sb: StringBuilder, text: String, xRight: Float, y: Float, size: Float, maxW: Float, bold: Boolean = false) {
        val font = if (bold) faFont.deriveFont(Font.BOLD) else faFont
        val tl = TextLayout(text, font, FontRenderContext(null, true, true))
        var sc = size / 100f
        if (tl.advance * sc > maxW) sc = maxW / tl.advance
        val sh = tl.getOutline(null)
        val x0 = xRight - tl.advance * sc
        val pi = sh.getPathIterator(null)
        val c = FloatArray(6)
        var cx = 0f; var cy = 0f
        fun X(v: Float) = f(x0 + v * sc)
        fun Y(v: Float) = f(y - v * sc)
        sb.append("0 g\n")
        while (!pi.isDone) {
            when (pi.currentSegment(c)) {
                PathIterator.SEG_MOVETO -> { sb.append("${X(c[0])} ${Y(c[1])} m\n"); cx = c[0]; cy = c[1] }
                PathIterator.SEG_LINETO -> { sb.append("${X(c[0])} ${Y(c[1])} l\n"); cx = c[0]; cy = c[1] }
                PathIterator.SEG_QUADTO -> {
                    val c1x = cx + 2f / 3f * (c[0] - cx); val c1y = cy + 2f / 3f * (c[1] - cy)
                    val c2x = c[2] + 2f / 3f * (c[0] - c[2]); val c2y = c[3] + 2f / 3f * (c[1] - c[3])
                    sb.append("${X(c1x)} ${Y(c1y)} ${X(c2x)} ${Y(c2y)} ${X(c[2])} ${Y(c[3])} c\n"); cx = c[2]; cy = c[3]
                }
                PathIterator.SEG_CUBICTO -> { sb.append("${X(c[0])} ${Y(c[1])} ${X(c[2])} ${Y(c[3])} ${X(c[4])} ${Y(c[5])} c\n"); cx = c[4]; cy = c[5] }
                PathIterator.SEG_CLOSE -> sb.append("h\n")
            }
            pi.next()
        }
        sb.append("f\n")
    }

    // قاب هر وجه: [مبدأ(3)، X(3)، Y(3)] — همان قراردادِ برنامه‌ی گوشی (دید از بیرون، Y بالا)
    fun faceFrame(face: Int, s: FloatArray): FloatArray = when (face) {
        0 -> floatArrayOf(0f, 0f, s[2], 1f, 0f, 0f, 0f, 1f, 0f)
        1 -> floatArrayOf(s[0], 0f, 0f, -1f, 0f, 0f, 0f, 1f, 0f)
        2 -> floatArrayOf(s[0], 0f, s[2], 0f, 0f, -1f, 0f, 1f, 0f)
        3 -> floatArrayOf(0f, 0f, 0f, 0f, 0f, 1f, 0f, 1f, 0f)
        4 -> floatArrayOf(0f, s[1], s[2], 1f, 0f, 0f, 0f, 0f, -1f)
        else -> floatArrayOf(0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f)
    }

    /** شکل سه‌بعدی ساده‌ی جعبه‌ی قطعه با وجهِ چسباندن رنگی (x0,y0 = گوشه‌ی پایین-چپ ناحیه، w×h به پوینت) */
    private fun isoBox(sb: StringBuilder, x0: Float, y0: Float, w: Float, h: Float, size: FloatArray, face: Int) {
        val mx = max(size[0], max(size[1], size[2])).coerceAtLeast(1e-6f)
        val d = floatArrayOf(max(size[0] / mx, 0.14f), max(size[1] / mx, 0.14f), max(size[2] / mx, 0.14f))
        val nrm = arrayOf(floatArrayOf(0f, 0f, 1f), floatArrayOf(0f, 0f, -1f), floatArrayOf(1f, 0f, 0f), floatArrayOf(-1f, 0f, 0f), floatArrayOf(0f, 1f, 0f), floatArrayOf(0f, -1f, 0f))[face]
        val upv = if (abs(nrm[1]) > 0.5f) floatArrayOf(0f, 0f, -1f) else floatArrayOf(0f, 1f, 0f)
        fun cross(a: FloatArray, b: FloatArray) = floatArrayOf(a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])
        fun nrmz(a: FloatArray): FloatArray { val l = sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2]); return floatArrayOf(a[0] / l, a[1] / l, a[2] / l) }
        val side = nrmz(cross(upv, nrm))
        val dir = nrmz(floatArrayOf(nrm[0] + 0.7f * upv[0] + 0.7f * side[0], nrm[1] + 0.7f * upv[1] + 0.7f * side[1], nrm[2] + 0.7f * upv[2] + 0.7f * side[2]))
        val r = nrmz(cross(upv, dir)); val u = cross(dir, r)
        fun pr(p: FloatArray) = floatArrayOf(p[0] * r[0] + p[1] * r[1] + p[2] * r[2], p[0] * u[0] + p[1] * u[1] + p[2] * u[2])
        fun vtx(i: Int) = floatArrayOf(if (i and 1 != 0) d[0] / 2 else -d[0] / 2, if (i and 2 != 0) d[1] / 2 else -d[1] / 2, if (i and 4 != 0) d[2] / 2 else -d[2] / 2)
        val P = Array(8) { pr(vtx(it)) }
        var minX = 1e9f; var maxX = -1e9f; var minY = 1e9f; var maxY = -1e9f
        for (p in P) { minX = min(minX, p[0]); maxX = max(maxX, p[0]); minY = min(minY, p[1]); maxY = max(maxY, p[1]) }
        val sc = min(w / (maxX - minX).coerceAtLeast(1e-6f), h / (maxY - minY).coerceAtLeast(1e-6f))
        val ox = x0 + (w - (maxX - minX) * sc) / 2f; val oy = y0 + (h - (maxY - minY) * sc) / 2f
        fun sx(p: FloatArray) = ox + (p[0] - minX) * sc
        fun sy(p: FloatArray) = oy + (p[1] - minY) * sc
        // وجه هدف
        val axis = when (face) { 0, 1 -> 2; 2, 3 -> 0; else -> 1 }
        val sgn = if (face % 2 == 0) 1 else 0           // وجه زوج = سمت +
        val ids = (0..7).filter { ((it shr axis) and 1) == sgn }
        val a1 = (axis + 1) % 3; val a2 = (axis + 2) % 3
        val order = listOf(0 to 0, 1 to 0, 1 to 1, 0 to 1).map { (p, q) -> ids.first { ((it shr a1) and 1) == p && ((it shr a2) and 1) == q } }
        sb.append("0.62 0.88 0.70 rg ${f(sx(P[order[0]]))} ${f(sy(P[order[0]]))} m ")
        for (k in 1..3) sb.append("${f(sx(P[order[k]]))} ${f(sy(P[order[k]]))} l ")
        sb.append("h f\n")
        // لبه‌ها
        sb.append("0.25 G 0.5 w\n")
        for (a in 0 until 8) for (bit in 0..2) {
            val b = a xor (1 shl bit)
            if (b > a) sb.append("${f(sx(P[a]))} ${f(sy(P[a]))} m ${f(sx(P[b]))} ${f(sy(P[b]))} l S\n")
        }
        sb.append("0.1 0.55 0.2 RG 1.1 w ${f(sx(P[order[0]]))} ${f(sy(P[order[0]]))} m ")
        for (k in 1..3) sb.append("${f(sx(P[order[k]]))} ${f(sy(P[order[k]]))} l ")
        sb.append("h S\n")
    }

    /** نمای روبه‌رو از وجه چسباندن: اعضای مدل (خاکستری) + جای برچسب (قرمز) + نشان «بالا» */
    private fun faceView(sb: StringBuilder, x0: Float, y0: Float, w: Float, h: Float, lb: Label, u: Float) {
        val fr = faceFrame(lb.face, lb.size)
        val s = lb.size
        val wf = abs(fr[3] * s[0] + fr[4] * s[1] + fr[5] * s[2]).coerceAtLeast(1e-4f)
        val hf = abs(fr[6] * s[0] + fr[7] * s[1] + fr[8] * s[2]).coerceAtLeast(1e-4f)
        val aw = w - 4f; val ah = h - 6f                         // ناحیه‌ی رسم (جا برای «بالا»)
        val sc = min(aw / wf, ah / hf)
        val ow = wf * sc; val oh = hf * sc
        val ox = x0 + (w - ow) / 2f; val oy = y0 + 1f
        // اعضا
        sb.append("0.62 G 0.25 w 0.93 g\n")
        val big = lb.boxes.sortedByDescending { (it[3] - it[0]) * (it[4] - it[1]) * (it[5] - it[2]) }.take(70)
        for (b in big) {
            var lx0 = 1e9f; var lx1 = -1e9f; var ly0 = 1e9f; var ly1 = -1e9f
            for (i in 0..7) {
                val px = if (i and 1 != 0) b[3] else b[0]; val py = if (i and 2 != 0) b[4] else b[1]; val pz = if (i and 4 != 0) b[5] else b[2]
                val qx = px - fr[0]; val qy = py - fr[1]; val qz = pz - fr[2]
                val a = qx * fr[3] + qy * fr[4] + qz * fr[5]; val c = qx * fr[6] + qy * fr[7] + qz * fr[8]
                lx0 = min(lx0, a); lx1 = max(lx1, a); ly0 = min(ly0, c); ly1 = max(ly1, c)
            }
            sb.append("${f(ox + lx0 * sc)} ${f(oy + ly0 * sc)} ${f(max((lx1 - lx0) * sc, 0.3f))} ${f(max((ly1 - ly0) * sc, 0.3f))} re B\n")
        }
        sb.append("0 G 0.6 w ${f(ox)} ${f(oy)} ${f(ow)} ${f(oh)} re S\n")
        // جای برچسب (مربع قرمز)
        val ls = 4.4f * PT
        val cx = ox + u * ow; val cy = oy + 0.5f * oh
        sb.append("0.85 0.1 0.1 rg ${f(cx - ls / 2)} ${f(cy - ls / 2)} ${f(ls)} ${f(ls)} re f\n")
        sb.append("1 g ${f(cx - ls * 0.12f)} ${f(cy - ls * 0.28f)} ${f(ls * 0.24f)} ${f(ls * 0.56f)} re f\n")
        // فلش «بالا»
        val ax = ox + ow + 1.5f
        sb.append("0 g 0 G 0.7 w ${f(ax)} ${f(oy)} m ${f(ax)} ${f(oy + oh)} l S ${f(ax - 1.6f)} ${f(oy + oh - 2.4f)} m ${f(ax)} ${f(oy + oh)} l ${f(ax + 1.6f)} ${f(oy + oh - 2.4f)} l S\n")
    }

    private fun grid(codeMm: Float): IntArray {
        val w = codeMm * 1.2f; val h = codeMm * 1.2f + STRIP_MM
        val cols = ((PW / PT - 2 * MARGIN + GAP) / (w + GAP)).toInt().coerceAtLeast(1)
        val rows = (((PH / PT) - MARGIN - 14f + GAP) / (h + GAP)).toInt().coerceAtLeast(1)
        return intArrayOf(cols, rows)
    }

    private fun flag(sb: StringBuilder, x: Float, y: Float, w: Float, h: Float) {
        sb.append("0.137 0.624 0.251 rg ${f(x)} ${f(y + 2 * h / 3)} ${f(w)} ${f(h / 3)} re f\n")
        sb.append("1 g ${f(x)} ${f(y + h / 3)} ${f(w)} ${f(h / 3)} re f\n")
        sb.append("0.855 0 0 rg ${f(x)} ${f(y)} ${f(w)} ${f(h / 3)} re f\n")
        sb.append("0.3 w 0.5 G ${f(x)} ${f(y)} ${f(w)} ${f(h)} re S\n")
        val ex = x + w / 2; val ey = y + h / 2; val u = h * 0.15f
        sb.append("0.855 0 0 RG ${f(0.45f * u + 0.3f)} w 1 J\n")
        sb.append("${f(ex - 0.35f * u)} ${f(ey + u)} m ${f(ex - 1.4f * u)} ${f(ey + 0.6f * u)} ${f(ex - 1.4f * u)} ${f(ey - 0.6f * u)} ${f(ex - 0.35f * u)} ${f(ey - u)} c S\n")
        sb.append("${f(ex + 0.35f * u)} ${f(ey + u)} m ${f(ex + 1.4f * u)} ${f(ey + 0.6f * u)} ${f(ex + 1.4f * u)} ${f(ey - 0.6f * u)} ${f(ex + 0.35f * u)} ${f(ey - u)} c S\n")
        sb.append("${f(ex)} ${f(ey - 1.1f * u)} m ${f(ex)} ${f(ey + 1.1f * u)} l S\n")
    }

    val POS_U = floatArrayOf(0.5f, 0.25f, 0.75f)           // وسط، چپ، راست (کسری از عرض وجه)
    private val POS_FA = arrayOf("وسط وجه", "سمت چپ وجه", "سمت راست وجه")

    /** تصویر پرچم (منبع flag.png) به‌صورت RGB فشرده‌شده؛ null اگر نبود */
    private class Img(val w: Int, val h: Int, val data: ByteArray)
    private val flagImg: Img? by lazy {
        try {
            val st = PdfMarker::class.java.getResourceAsStream("/flag.png") ?: return@lazy null
            val bi = st.use { ImageIO.read(it) } ?: return@lazy null
            val raw = ByteArray(bi.width * bi.height * 3)
            var k = 0
            for (y in 0 until bi.height) for (x in 0 until bi.width) {
                val p = bi.getRGB(x, y); val a = (p ushr 24) and 255
                fun mix(c: Int) = ((c * a + 255 * (255 - a)) / 255).toByte()
                raw[k++] = mix((p shr 16) and 255); raw[k++] = mix((p shr 8) and 255); raw[k++] = mix(p and 255)
            }
            val df = Deflater(9); df.setInput(raw); df.finish()
            val bo = ByteArrayOutputStream(); val buf = ByteArray(8192)
            while (!df.finished()) { val n = df.deflate(buf); bo.write(buf, 0, n) }
            Img(bi.width, bi.height, bo.toByteArray())
        } catch (_: Throwable) { null }
    }

    private fun page(labels: List<Label>, cols: Int, rows: Int): String {
        val sb = StringBuilder()
        fun text(x: Float, y: Float, size: Float, bold: Boolean, t: String) {
            sb.append("0 g BT /${if (bold) "F2" else "F1"} ${f(size)} Tf ${f(x)} ${f(y)} Td (${esc(t)}) Tj ET\n")
        }
        for ((i, lb) in labels.withIndex()) {
            val c = i % cols; val r = i / cols
            val S = lb.codeMm
            val W = S * 1.2f; val H = S * 1.2f + STRIP_MM
            val lx = mm(MARGIN + c * (W + GAP))
            val ly = PH - mm(MARGIN + (r + 1) * H + r * GAP)
            // خط برش
            sb.append("0.4 w 0.55 G ${f(lx)} ${f(ly)} ${f(mm(W))} ${f(mm(H))} re S\n")
            // هولوگرام
            val n = lb.matrix.size
            val modPt = mm(S) / n
            val qx = lx + mm(0.1f * S); val qy = ly + mm(STRIP_MM) + mm(0.1f * S)
            sb.append("0 g\n")
            for (row in 0 until n) {
                var cc = 0
                while (cc < n) {
                    if (lb.matrix[row][cc]) {
                        var e = cc
                        while (e + 1 < n && lb.matrix[row][e + 1]) e++
                        sb.append("${f(qx + cc * modPt)} ${f(qy + (n - 1 - row) * modPt)} ${f((e - cc + 1) * modPt)} ${f(modPt)} re\n")
                        cc = e + 1
                    } else cc++
                }
            }
            sb.append("f\n")
            // نوشته‌ها
            val maxW = mm(W - 4f)
            val code = lb.code
            val fs = minOf(13f, (maxW - mm(18f)) / (code.length.coerceAtLeast(1) * 0.6f)).coerceAtLeast(6f)
            text(lx + mm(2f), ly + mm(STRIP_MM - 7.5f), fs, true, code)
            text(lx + mm(2f), ly + mm(STRIP_MM - 12.5f), 9f, true, "FabSteel QC AR")
            text(lx + mm(2f), ly + mm(STRIP_MM - 17f), 8f, false, "Eng Davod Bagheri")
            val fi = flagImg
            if (fi != null) {
                val fw = mm(15f); val fh = fw * fi.h / fi.w
                sb.append("q ${f(fw)} 0 0 ${f(fh)} ${f(lx + mm(W - 2f) - fw)} ${f(ly + mm(STRIP_MM - 4f) - fh)} cm /Im1 Do Q\n")
            } else flag(sb, lx + mm(W - 2f - 13f), ly + mm(STRIP_MM - 17f), mm(13f), mm(8.7f))
            // شکل‌ها: چپ = قطعه با وجه رنگی ؛ راست = نمای روبه‌روی وجه و جای برچسب
            val dY = ly + mm(STRIP_MM - 41.5f); val dH = mm(21f)
            val half = (mm(W) - mm(6f)) / 2f
            isoBox(sb, lx + mm(2f), dY, half, dH, lb.size, lb.face)
            faceView(sb, lx + mm(4f) + half, dY, half, dH, lb, POS_U[lb.pos])
            // متن فارسی محل چسباندن
            val xr = lx + mm(W - 2f); val mw = mm(W - 4f)
            fa(sb, "روی وجه سبزرنگ شکل بچسبانید", xr, ly + mm(15.2f), 7.6f, mw, true)
            fa(sb, "جای برچسب: " + POS_FA[lb.pos] + " (مربع قرمز)", xr, ly + mm(10.8f), 7.4f, mw)
            fa(sb, "بالای برچسب = بالای شکل؛ دقت میلی‌متری لازم نیست", xr, ly + mm(6.8f), 6.4f, mw)
            text(lx + mm(2f), ly + mm(2.2f), 5.5f, false, "${FACE_EN_PDF[lb.face]} | ID ${lb.id} | ${S.toInt()} mm")
        }
        // پاورقی
        val cm = labels.firstOrNull()?.codeMm ?: 50f
        text(mm(MARGIN), mm(7f), 8f, false, "Print at 100% / Actual size (NOT Fit to page). All dimensions in mm. Cut along grey lines. Glue as shown in the drawing (green face, red square).")
        val bx = mm(MARGIN); val by = mm(11f)
        sb.append("0 g 0 G 0.8 w ${f(bx)} ${f(by)} m ${f(bx + mm(cm))} ${f(by)} l S 0.8 w ${f(bx)} ${f(by - 2)} m ${f(bx)} ${f(by + 2)} l S ${f(bx + mm(cm))} ${f(by - 2)} m ${f(bx + mm(cm))} ${f(by + 2)} l S\n")
        text(bx + mm(cm) + 6f, by - 3f, 8f, false, "this bar = ${cm.toInt()} mm")
        return sb.toString()
    }

    private val FACE_EN_PDF = arrayOf("FRONT (+Z)", "BACK (-Z)", "RIGHT (+X)", "LEFT (-X)", "TOP (+Y)", "BOTTOM (-Y)")

    fun build(labels: List<Label>): ByteArray {
        val cm = labels.first().codeMm
        val (cols, rows) = grid(cm).let { it[0] to it[1] }
        val per = cols * rows
        val chunks = labels.chunked(per)
        val out = ByteArrayOutputStream()
        val offs = ArrayList<Int>()
        fun w(s: String) = out.write(s.toByteArray(Charsets.ISO_8859_1))
        fun obj(body: String) { offs.add(out.size()); w("${offs.size} 0 obj\n$body\nendobj\n") }
        val imgNo = 5 + chunks.size * 2
        w("%PDF-1.4\n")
        val kids = chunks.indices.joinToString(" ") { "${5 + it * 2} 0 R" }
        obj("<< /Type /Catalog /Pages 2 0 R >>")
        obj("<< /Type /Pages /Kids [$kids] /Count ${chunks.size} >>")
        obj("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>")
        obj("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>")
        for ((i, ch) in chunks.withIndex()) {
            val c = page(ch, cols, rows)
            obj("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${f(PW)} ${f(PH)}] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> /XObject << /Im1 $imgNo 0 R >> >> /Contents ${6 + i * 2} 0 R >>")
            obj("<< /Length ${c.length} >>\nstream\n$c\nendstream")
        }
        val fi = flagImg
        if (fi != null) {
            offs.add(out.size())
            w("${offs.size} 0 obj\n<< /Type /XObject /Subtype /Image /Width ${fi.w} /Height ${fi.h} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /FlateDecode /Length ${fi.data.size} >>\nstream\n")
            out.write(fi.data); w("\nendstream\nendobj\n")
        } else {
            obj("<< >>")
        }
        val xr = out.size()
        w("xref\n0 ${offs.size + 1}\n0000000000 65535 f \n")
        for (o in offs) w(String.format(Locale.US, "%010d 00000 n \n", o))
        w("trailer\n<< /Size ${offs.size + 1} /Root 1 0 R >>\nstartxref\n$xr\n%%EOF\n")
        return out.toByteArray()
    }
}
