package ir.fabsteel.arqc

import android.content.Context
import android.graphics.*
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.*

/** نمای سه‌بعدی ساده‌ی مدل IFC با چرخش، زوم و جابه‌جایی (رسم خطوط لبه روی Canvas). */
class ModelView(c: Context) : View(c) {
    private var segs = FloatArray(0)
    private var cx = 0f; private var cy = 0f; private var cz = 0f; private var radius = 1f
    var yaw = 0.7f; var pitch = 0.5f; private var zoom = 1f
    private var panX = 0f; private var panY = 0f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF5EC8FF.toInt(); strokeWidth = 1.6f; style = Paint.Style.STROKE
    }
    private val holePaint = Paint(paint).apply { color = 0xFFFFC107.toInt() }
    private var holeSegs = FloatArray(0)
    private var lx = 0f; private var ly = 0f
    private var tris = FloatArray(0)      // سه‌گوشه‌ها (۹ عدد برای هر مثلث)
    var layer = 1                         // 1: شیشه‌ای | 2: توپر کم‌رنگ | 3: توپر کامل
    private val fillPaint = Paint()
    fun applyLayer(l: Int) { layer = l; invalidate() }

    private val sd = ScaleGestureDetector(c, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean { zoom = (zoom * d.scaleFactor).coerceIn(0.1f, 60f); invalidate(); return true }
    })

    fun setModel(m: IfcModel?) {
        if (m == null) { segs = FloatArray(0); holeSegs = FloatArray(0); invalidate(); return }
        val a = ArrayList<Float>(); val h = ArrayList<Float>()
        var total = 0L
        for (mb in m.members) total += mb.edges.size
        val step = max(1, (total / 6 / 150000).toInt()) // حداکثر حدود ۱۵۰ هزار پاره‌خط
        var k = 0
        for (mb in m.members) {
            val dst = if (mb.isHole) h else a
            var i = 0
            while (i + 5 < mb.edges.size) {
                if (k++ % step == 0) for (j in 0..5) dst.add(mb.edges[i + j])
                i += 6
            }
        }
        segs = a.toFloatArray(); holeSegs = h.toFloatArray()
        var tt = 0L
        for (mb in m.members) if (!mb.isHole) tt += mb.tris.size / 9
        val ts = max(1, (tt / 7000).toInt())
        val tl = ArrayList<Float>()
        var kk = 0
        for (mb in m.members) {
            if (mb.isHole) continue
            var t = 0
            while (t + 8 < mb.tris.size) {
                if (kk++ % ts == 0) for (j in 0..8) tl.add(mb.tris[t + j])
                t += 9
            }
        }
        tris = tl.toFloatArray()
        val s = m.sizeM
        cx = s[0] / 2; cy = s[1] / 2; cz = s[2] / 2
        radius = max(0.001f, sqrt(s[0] * s[0] + s[1] * s[1] + s[2] * s[2]) / 2)
        fit(); invalidate()
    }
    fun fit() { zoom = 1f; panX = 0f; panY = 0f; invalidate() }
    fun iso() { yaw = 0.7f; pitch = 0.5f; fit() }

    private val darkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF3A3F45.toInt(); strokeWidth = 1.2f; style = Paint.Style.STROKE }

    private fun drawFill(c: Canvas, sc: Float, cyw: Float, syw: Float, cp: Float, sp: Float, ox: Float, oy: Float) {
        val n = tris.size / 9
        val vx = FloatArray(n * 6); val col = IntArray(n * 3); val dep = FloatArray(n)
        val solid = layer == 3
        for (t in 0 until n) {
            val sxs = FloatArray(3); val sys = FloatArray(3); val vv = FloatArray(9)
            var zs = 0f
            for (q in 0..2) {
                val x = tris[t * 9 + q * 3] - cx; val y = tris[t * 9 + q * 3 + 1] - cy; val z = tris[t * 9 + q * 3 + 2] - cz
                val x1 = x * cyw + z * syw; val z1 = -x * syw + z * cyw
                val y2 = y * cp - z1 * sp; val z2 = y * sp + z1 * cp
                vv[q * 3] = x1; vv[q * 3 + 1] = y2; vv[q * 3 + 2] = z2
                sxs[q] = ox + x1 * sc; sys[q] = oy - y2 * sc
                zs += z2
            }
            dep[t] = zs
            val ux = vv[3] - vv[0]; val uy = vv[4] - vv[1]; val uz = vv[5] - vv[2]
            val wx = vv[6] - vv[0]; val wy = vv[7] - vv[1]; val wz = vv[8] - vv[2]
            var nx = uy * wz - uz * wy; var ny = uz * wx - ux * wz; var nz = ux * wy - uy * wx
            val l = sqrt(nx * nx + ny * ny + nz * nz)
            val d = if (l > 1e-9f) abs((0.3f * nx + 0.5f * ny + 0.8f * nz) / l) else 0.5f
            val sh = 0.35f + 0.65f * d
            val br = if (solid) 0xB4 else 0x5E; val bg = if (solid) 0xB4 else 0xA8; val bb = if (solid) 0xB8 else 0xE0
            val r = (br * sh).toInt().coerceIn(0, 255); val g = (bg * sh).toInt().coerceIn(0, 255); val b = (bb * sh).toInt().coerceIn(0, 255)
            val cc = if (solid) (0xFF shl 24) or (r shl 16) or (g shl 8) or b else (0x55 shl 24) or (r shl 16) or (g shl 8) or b
            for (q in 0..2) { vx[t * 6 + q * 2] = sxs[q]; vx[t * 6 + q * 2 + 1] = sys[q]; col[t * 3 + q] = cc }
        }
        val ov: FloatArray; val oc: IntArray
        if (solid) {
            val idx = (0 until n).sortedBy { dep[it] }
            ov = FloatArray(n * 6); oc = IntArray(n * 3)
            for ((k, t) in idx.withIndex()) {
                for (q in 0 until 6) ov[k * 6 + q] = vx[t * 6 + q]
                for (q in 0 until 3) oc[k * 3 + q] = col[t * 3 + q]
            }
        } else { ov = vx; oc = col }
        c.drawVertices(Canvas.VertexMode.TRIANGLES, ov.size, ov, 0, null, 0, oc, 0, null, 0, 0, fillPaint)
    }

    override fun onDraw(c: Canvas) {
        c.drawColor(if (layer == 3) 0xFF7FB6E6.toInt() else 0xFF0A1226.toInt())
        val sc = min(width, height) / 2f / radius * zoom * 0.9f
        val cyw = cos(yaw); val syw = sin(yaw); val cp = cos(pitch); val sp = sin(pitch)
        val ox = width / 2f + panX; val oy = height / 2f + panY
        fun draw(arr: FloatArray, p: Paint) {
            if (arr.isEmpty()) return
            val out = FloatArray(arr.size / 3 * 2)
            var i = 0; var o = 0
            while (i + 2 < arr.size) {
                val x = arr[i] - cx; val y = arr[i + 1] - cy; val z = arr[i + 2] - cz
                val x1 = x * cyw + z * syw; val z1 = -x * syw + z * cyw
                val y2 = y * cp - z1 * sp
                out[o++] = ox + x1 * sc; out[o++] = oy - y2 * sc
                i += 3
            }
            c.drawLines(out, p)
        }
        if (layer >= 2 && tris.isNotEmpty()) drawFill(c, sc, cyw, syw, cp, sp, ox, oy)
        draw(segs, if (layer == 3) darkPaint else paint); draw(holeSegs, holePaint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        sd.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_UP -> { lx = e.x; ly = e.y }
            MotionEvent.ACTION_MOVE -> if (!sd.isInProgress) {
                val dx = e.x - lx; val dy = e.y - ly; lx = e.x; ly = e.y
                if (e.pointerCount >= 2) { panX += dx; panY += dy }
                else { yaw += dx * 0.01f; pitch = (pitch + dy * 0.01f).coerceIn(-1.5f, 1.5f) }
                invalidate()
            } else { lx = e.x; ly = e.y }
        }
        return true
    }
}

class Viewer3dActivity : AppCompatActivity() {
    private lateinit var mv: ModelView
    private lateinit var status: TextView
    private val pick = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            status.text = "در حال خواندن فایل…"
            IfcLoader.load(this, uri, { status.text = it }) { m, err ->
                if (m != null) { mv.setModel(m); status.text = "${m.members.size} قطعه" }
                else if (err == IfcLoader.PDF_ERR) {
                    status.text = "3D PDF پشتیبانی نمی‌شود"
                    androidx.appcompat.app.AlertDialog.Builder(this)
                        .setTitle("3D PDF")
                        .setMessage("خواندن مدل داخل 3D PDF هنوز پشتیبانی نمی‌شود (فرمت U3D فشرده است).\n\nاز تکلا با ماکروی FabQC خروجی بگیرید (فایل .fabqc) یا از IFC استفاده کنید؛ هر دو اینجا به‌صورت سه‌بعدی باز می‌شوند.")
                        .setPositiveButton("OK", null).show()
                }
                else status.text = "خطا: $err"
            }
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        mv = ModelView(this)
        root.addView(mv, LinearLayout.LayoutParams(-1, 0, 1f))
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(8, 8, 8, 8); setBackgroundColor(0xFF0A1226.toInt()) }
        fun btn(t: String, a: () -> Unit) = Button(this).apply { text = t; textSize = 18f; setOnClickListener { a() } }
            .also { bar.addView(it, LinearLayout.LayoutParams(0, -2, 1f)) }
        btn("3D PDF UPLOAD") { pick.launch(arrayOf("*/*")) }
        btn("Fit") { mv.fit() }
        btn("Iso") { mv.iso() }
        btn("1") { mv.applyLayer(1) }
        btn("2") { mv.applyLayer(2) }
        btn("3") { mv.applyLayer(3) }
        status = TextView(this).apply { setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER }
        bar.addView(status, LinearLayout.LayoutParams(0, -2, 1.3f))
        btn("⌂ منو") { finish() }
        root.addView(bar)
        setContentView(root)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        ModelStore.model?.let { mv.setModel(it); status.text = "${it.members.size} قطعه" }
    }
}
