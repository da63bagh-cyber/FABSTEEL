package ir.fabsteel.arqc

import android.Manifest
import android.animation.ObjectAnimator
import android.content.Context
import android.content.pm.PackageManager
import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Point
import android.os.Build
import android.provider.MediaStore
import android.graphics.Color
import android.graphics.Paint
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.Surface
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.AspectRatio
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

// ---------- ریاضی ماتریس 3x3 (سطری) ----------
private fun mmul(a: FloatArray, b: FloatArray): FloatArray {
    val r = FloatArray(9)
    for (i in 0..2) for (j in 0..2) {
        var s = 0f
        for (k in 0..2) s += a[i * 3 + k] * b[k * 3 + j]
        r[i * 3 + j] = s
    }
    return r
}
private fun mT(a: FloatArray) = floatArrayOf(a[0], a[3], a[6], a[1], a[4], a[7], a[2], a[5], a[8])
private fun mv(a: FloatArray, x: Float, y: Float, z: Float) = floatArrayOf(
    a[0] * x + a[1] * y + a[2] * z,
    a[3] * x + a[4] * y + a[5] * z,
    a[6] * x + a[7] * y + a[8] * z
)
private fun rotX(t: Float): FloatArray { val c = cos(t); val s = sin(t); return floatArrayOf(1f, 0f, 0f, 0f, c, -s, 0f, s, c) }
private fun rotY(t: Float): FloatArray { val c = cos(t); val s = sin(t); return floatArrayOf(c, 0f, s, 0f, 1f, 0f, -s, 0f, c) }
private fun rotZ(t: Float): FloatArray { val c = cos(t); val s = sin(t); return floatArrayOf(c, -s, 0f, s, c, 0f, 0f, 0f, 1f) }

/** حل پوز یک مربع مسطح (چهار گوشه: TL,TR,BR,BL؛ مختصات نرمال‌شده‌ی تصویر) → [R(9, سطری)، t(3)] در دستگاه CV (x راست، y پایین، z جلو) */
private fun markerPose(us: FloatArray, vs: FloatArray, side: Float): FloatArray? {
    val h = side / 2f
    val px = floatArrayOf(-h, h, h, -h); val py = floatArrayOf(h, h, -h, -h)
    val a = Array(8) { DoubleArray(9) }
    for (i in 0..3) {
        val X = px[i].toDouble(); val Y = py[i].toDouble(); val u = us[i].toDouble(); val v = vs[i].toDouble()
        a[2 * i] = doubleArrayOf(X, Y, 1.0, 0.0, 0.0, 0.0, -u * X, -u * Y, u)
        a[2 * i + 1] = doubleArrayOf(0.0, 0.0, 0.0, X, Y, 1.0, -v * X, -v * Y, v)
    }
    for (c in 0 until 8) {
        var piv = c
        for (r in c + 1 until 8) if (abs(a[r][c]) > abs(a[piv][c])) piv = r
        if (abs(a[piv][c]) < 1e-12) return null
        val tmp = a[c]; a[c] = a[piv]; a[piv] = tmp
        for (r in 0 until 8) if (r != c) {
            val f = a[r][c] / a[c][c]
            for (k in c until 9) a[r][k] -= f * a[c][k]
        }
    }
    val hh = DoubleArray(8) { a[it][8] / a[it][it] }
    var h1 = doubleArrayOf(hh[0], hh[3], hh[6]); var h2 = doubleArrayOf(hh[1], hh[4], hh[7]); val h3 = doubleArrayOf(hh[2], hh[5], 1.0)
    val n1 = sqrt(h1[0] * h1[0] + h1[1] * h1[1] + h1[2] * h1[2]); val n2 = sqrt(h2[0] * h2[0] + h2[1] * h2[1] + h2[2] * h2[2])
    if (n1 < 1e-9 || n2 < 1e-9) return null
    val lam = 2.0 / (n1 + n2)
    var r1 = doubleArrayOf(h1[0] * lam, h1[1] * lam, h1[2] * lam)
    var r2 = doubleArrayOf(h2[0] * lam, h2[1] * lam, h2[2] * lam)
    val t = doubleArrayOf(h3[0] * lam, h3[1] * lam, h3[2] * lam)
    val l1 = sqrt(r1[0] * r1[0] + r1[1] * r1[1] + r1[2] * r1[2])
    r1 = doubleArrayOf(r1[0] / l1, r1[1] / l1, r1[2] / l1)
    val d = r1[0] * r2[0] + r1[1] * r2[1] + r1[2] * r2[2]
    r2 = doubleArrayOf(r2[0] - d * r1[0], r2[1] - d * r1[1], r2[2] - d * r1[2])
    val l2 = sqrt(r2[0] * r2[0] + r2[1] * r2[1] + r2[2] * r2[2])
    r2 = doubleArrayOf(r2[0] / l2, r2[1] / l2, r2[2] / l2)
    val r3 = doubleArrayOf(r1[1] * r2[2] - r1[2] * r2[1], r1[2] * r2[0] - r1[0] * r2[2], r1[0] * r2[1] - r1[1] * r2[0])
    if (t[2] <= 0.0) return null
    return floatArrayOf(
        r1[0].toFloat(), r2[0].toFloat(), r3[0].toFloat(),
        r1[1].toFloat(), r2[1].toFloat(), r3[1].toFloat(),
        r1[2].toFloat(), r2[2].toFloat(), r3[2].toFloat(),
        t[0].toFloat(), t[1].toFloat(), t[2].toFloat())
}

/** قاب مارکر روی هر وجه جعبه‌ی محیطی مدل: [مبدأ(3)، X(3)، Y(3)] در دستگاه مدل (Y بالا، گوشه‌ی مینیمم در مبدأ) */
private fun faceFrame(face: Int, s: FloatArray): FloatArray = when (face) {
    0 -> floatArrayOf(0f, 0f, s[2], 1f, 0f, 0f, 0f, 1f, 0f)          // جلو (+z)
    1 -> floatArrayOf(s[0], 0f, 0f, -1f, 0f, 0f, 0f, 1f, 0f)         // پشت (−z)
    2 -> floatArrayOf(s[0], 0f, s[2], 0f, 0f, -1f, 0f, 1f, 0f)       // راست (+x)
    3 -> floatArrayOf(0f, 0f, 0f, 0f, 0f, 1f, 0f, 1f, 0f)            // چپ (−x)
    4 -> floatArrayOf(0f, s[1], s[2], 1f, 0f, 0f, 0f, 0f, -1f)       // بالا (+y)
    else -> floatArrayOf(0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f)         // پایین (−y)
}
private val FACE_NAMES = arrayOf("جلو (+Z)", "پشت (−Z)", "راست (+X)", "چپ (−X)", "بالا (+Y)", "پایین (−Y)")

class CamPose(val m: FloatArray, val px: Float, val py: Float, val pz: Float, val w: Int, val h: Int, val f: Float)

/** نمای روی دوربین: مدل را رسم می‌کند و با انگشت قابل تنظیم است؛ بعد از Fix با ژیروسکوپ ثابت می‌ماند. */
class CamOverlay(ctx: Context) : View(ctx) {
    private var model: IfcModel? = null
    var segs: List<FloatArray> = emptyList(); private set      // پاره‌خط‌های هر عضو (نسبت به مرکز)
    var samples: List<FloatArray> = emptyList(); private set   // نقاط نمونه‌ی هر عضو
    var isHole: BooleanArray = BooleanArray(0); private set
    var names: List<String> = emptyList(); private set
    @Volatile var redFlags: BooleanArray = BooleanArray(0)
    @Volatile var rot: FloatArray? = null

    private var cx = 0f; private var cy = 0f; private var cz = 0f
    private var radius = 1f
    private var yaw = 0f; private var pitch = 0f; private var roll = 0f
    private var tx = 0f; private var ty = 0f; private var dist = 2f
    private var needInit = true
    @Volatile var lockDepth = 1f
    @Volatile var fillLevel = 2                  // 0: خطی | 1: کم‌رنگ | 2: توپر
    @Volatile var fitFrames = 0                 // تعداد فریم‌های باقی‌مانده‌ی فیت خودکار بعد از Fix
    @Volatile var fitStatus = ""
    private var tfill: List<FloatArray> = emptyList()   // مثلث‌های هر عضو (نسبت به مرکز) برای پر کردن سطوح
    private var vBuf = FloatArray(0); private var cBuf = IntArray(0)
    private val fillPaint = Paint()
    @Volatile var trackImage = false   // true: ردیابی با تصویر دوربین + ژیروسکوپ؛ false: فقط ژیروسکوپ (دور قطعه)
    @Volatile var trkM = floatArrayOf(1f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 1f)
    @Volatile var trkP = floatArrayOf(0f, 0f, -2f)
    @Volatile var trkR: FloatArray? = null
    var trackPts: FloatArray = FloatArray(0); private set
    @Volatile var fixed = false; private set
    private var fixR: FloatArray? = null
    private var fixMc = floatArrayOf(1f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 1f)
    private var fixP = floatArrayOf(0f, 0f, 0f)

    private val okPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF39D0FF.toInt(); strokeWidth = 3.5f; style = Paint.Style.STROKE }
    private val holePaint = Paint(okPaint).apply { color = 0xFFFFC107.toInt() }
    private val redPaint = Paint(okPaint).apply { color = 0xFFFF2B2B.toInt(); strokeWidth = 6f }
    private var okBuf = FloatArray(0); private var holeBuf = FloatArray(0); private var redBuf = FloatArray(0)

    private val sd = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            if (fixed) return true
            dist = (dist / d.scaleFactor).coerceIn(0.05f, 200f); invalidate(); return true
        }
    })
    private var lx = 0f; private var ly = 0f; private var lastAng = 0f

    fun setModel(m: IfcModel?) {
        model = m
        if (m == null) { segs = emptyList(); samples = emptyList(); isHole = BooleanArray(0); names = emptyList(); invalidate(); return }
        val s = m.sizeM
        cx = s[0] / 2; cy = s[1] / 2; cz = s[2] / 2
        radius = max(0.001f, sqrt(s[0] * s[0] + s[1] * s[1] + s[2] * s[2]) / 2)
        var total = 0L
        for (mb in m.members) total += mb.edges.size / 6
        val step = max(1, (total / 120000).toInt())
        val sg = ArrayList<FloatArray>(); val sm = ArrayList<FloatArray>()
        val hl = BooleanArray(m.members.size); val nm = ArrayList<String>()
        var k = 0
        for ((i, mb) in m.members.withIndex()) {
            val o = ArrayList<Float>()
            var j = 0
            while (j + 5 < mb.edges.size) {
                if (k++ % step == 0) {
                    o.add(mb.edges[j] - cx); o.add(mb.edges[j + 1] - cy); o.add(mb.edges[j + 2] - cz)
                    o.add(mb.edges[j + 3] - cx); o.add(mb.edges[j + 4] - cy); o.add(mb.edges[j + 5] - cz)
                }
                j += 6
            }
            val arr = o.toFloatArray()
            sg.add(arr)
            // نقاط نمونه: وسط هر پاره‌خط، حداکثر 48 نقطه
            val nSeg = arr.size / 6
            val st = max(1, nSeg / 48)
            val p = ArrayList<Float>()
            var q = 0
            while (q < nSeg) {
                p.add((arr[q * 6] + arr[q * 6 + 3]) / 2); p.add((arr[q * 6 + 1] + arr[q * 6 + 4]) / 2); p.add((arr[q * 6 + 2] + arr[q * 6 + 5]) / 2)
                q += st
            }
            sm.add(p.toFloatArray())
            hl[i] = mb.isHole; nm.add(mb.name)
        }
        segs = sg; samples = sm; isHole = hl; names = nm
        run {
            var totT = 0L
            for (mb in m.members) if (!mb.isHole) totT += mb.tris.size / 9
            val ts = max(1, (totT / 9000).toInt())
            val tl = ArrayList<FloatArray>()
            var maxT = 0
            for (mb in m.members) {
                val o = ArrayList<Float>()
                if (!mb.isHole) {
                    var t = 0; var n = 0
                    while (t + 8 < mb.tris.size) {
                        if (n++ % ts == 0) for (q in 0 until 3) {
                            o.add(mb.tris[t + q * 3] - cx); o.add(mb.tris[t + q * 3 + 1] - cy); o.add(mb.tris[t + q * 3 + 2] - cz)
                        }
                        t += 9
                    }
                }
                val a = o.toFloatArray(); tl.add(a); maxT += a.size / 9
            }
            tfill = tl
            vBuf = FloatArray(maxT * 6); cBuf = IntArray(maxT * 3)
        }
        run {
            var tot = 0
            for (a in sm) tot += a.size / 3
            val stp = max(1, tot / 500)
            val tp = ArrayList<Float>()
            var kk = 0
            for (a in sm) {
                var q = 0
                while (q + 2 < a.size) {
                    if (kk++ % stp == 0) { tp.add(a[q]); tp.add(a[q + 1]); tp.add(a[q + 2]) }
                    q += 3
                }
            }
            trackPts = tp.toFloatArray()
        }
        var mx = 0
        for (a in sg) mx += a.size / 6
        okBuf = FloatArray(mx * 4); holeBuf = FloatArray(mx * 4); redBuf = FloatArray(mx * 4)
        redFlags = BooleanArray(m.members.size)
        yaw = 0.6f; pitch = 0.35f; roll = 0f; tx = 0f; ty = 0f
        needInit = true; fixed = false
        invalidate()
    }

    fun focal() = 0.73f * max(width, 1)

    private fun baseMc() = mmul(rotZ(roll), mmul(rotX(pitch), rotY(yaw)))

    fun pose(): CamPose {
        val f = focal()
        val r = rot
        val mc: FloatArray; val pc: FloatArray
        if (!fixed) {
            mc = baseMc(); pc = floatArrayOf(tx, ty, -dist)
        } else if (trackImage) {
            val m0 = trkM; val p0 = trkP; val r0 = trkR
            if (r != null && r0 != null) {
                val d = mmul(mT(r), r0)
                mc = mmul(d, m0); pc = mv(d, p0[0], p0[1], p0[2])
            } else { mc = m0; pc = p0 }
        } else {
            val r0 = fixR
            if (r != null && r0 != null) {
                mc = mmul(mmul(mT(r), r0), fixMc); pc = fixP
            } else { mc = fixMc; pc = fixP }
        }
        return CamPose(mc, pc[0], pc[1], pc[2], width, height, f)
    }

    fun lock() {
        fixMc = baseMc(); fixP = floatArrayOf(tx, ty, -dist)
        fixR = rot?.clone()
        lockDepth = max(0.05f, dist)
        fitFrames = 12; fitStatus = "فیت خودکار…"
        trkM = fixMc; trkP = fixP; trkR = fixR
        fixed = true; invalidate()
    }

    /** نتیجه‌ی ردیابی تصویر (مدل→دوربین) در لحظه‌ای که ماتریس ژیروسکوپ r بوده */
    fun setTracked(m: FloatArray, px: Float, py: Float, pz: Float, r: FloatArray?) {
        trkP = floatArrayOf(px, py, pz); trkM = m; trkR = r
        postInvalidate()
    }

    @Volatile var markerSeenAt = 0L
    /** پوز از روی مارکر: مدل را فیکس می‌کند و تا زمانی که مارکر دیده شود هر فریم اصلاح می‌شود */
    fun setFromMarker(face: Int, sizeM: FloatArray, rc: FloatArray, codeM: Float, rotNow: FloatArray?, dyM: Float = 0f): Boolean {
        val fr = faceFrame(face, sizeM)
        val mg = 0.1f * codeM
        val k = mg + codeM / 2f; val ky = k + dyM
        val cxm = fr[0] + k * fr[3] + ky * fr[6]; val cym = fr[1] + k * fr[4] + ky * fr[7]; val czm = fr[2] + k * fr[5] + ky * fr[8]
        val ax = floatArrayOf(fr[3], fr[4], fr[5]); val ay = floatArrayOf(fr[6], fr[7], fr[8])
        val az = floatArrayOf(ax[1] * ay[2] - ax[2] * ay[1], ax[2] * ay[0] - ax[0] * ay[2], ax[0] * ay[1] - ax[1] * ay[0])
        val rmT = floatArrayOf(ax[0], ax[1], ax[2], ay[0], ay[1], ay[2], az[0], az[1], az[2])
        val a = mmul(floatArrayOf(rc[0], rc[1], rc[2], rc[3], rc[4], rc[5], rc[6], rc[7], rc[8]), rmT)
        for (i in 3..8) a[i] = -a[i]                                  // دستگاه CV → دستگاه نمای برنامه (y,z وارونه)
        val w = mv(a, cx - cxm, cy - cym, cz - czm)
        val px = w[0] + rc[9]; val py = w[1] - rc[10]; val pz = w[2] - rc[11]
        val dep = -pz
        if (dep < 0.08f || dep > 8f) return false
        fixMc = a; fixP = floatArrayOf(px, py, pz); fixR = rotNow
        lockDepth = dep; fitFrames = 0
        trkM = a; trkP = fixP; trkR = rotNow
        markerSeenAt = System.currentTimeMillis()
        val was = fixed
        fixed = true
        postInvalidate()
        return !was
    }

    /** فیت خودکار: پوز اصلاح‌شده را به‌عنوان پوز قفل‌شده ذخیره می‌کند (حالت دور قطعه) */
    fun applyFit(m: FloatArray, px: Float, py: Float, pz: Float, r: FloatArray?) {
        fixMc = m; fixP = floatArrayOf(px, py, pz); fixR = r
        postInvalidate()
    }

    fun unlock() {
        fitFrames = 0
        // ادامه از آخرین حالت ردیابی‌شده
        if (fixed) {
            val p = pose()
            tx = p.px; ty = p.py; dist = max(0.05f, -p.pz)
            val m = p.m
            pitch = asin(m[7].coerceIn(-1f, 1f))
            yaw = atan2(-m[6], m[8])
            roll = atan2(-m[1], m[4])
        }
        fixed = false; invalidate()
    }
    fun pxPerMm(): Float { val p = pose(); return p.f / (max(0.05f, abs(p.pz)) * 1000f) }

    fun nudgeYaw(deg: Float) { if (!fixed) { yaw += Math.toRadians(deg.toDouble()).toFloat(); invalidate() } }

    override fun onDraw(c: Canvas) {
        val m = model ?: return
        if (width == 0) return
        if (needInit) {
            dist = max(0.2f, radius * focal() / (0.4f * min(width, height)))
            needInit = false
        }
        val p = pose()
        val flags = redFlags
        var no = 0; var nh = 0; var nr = 0
        val hw = width / 2f; val hh = height / 2f
        run {
            var nv = 0; var nc = 0
            for (i in tfill.indices) {
                val a = tfill[i]
                val red = i < flags.size && flags[i]
                val col = if (fillLevel >= 2) (if (red) 0xD0FF2B2B.toInt() else 0xB024D68A.toInt()) else (if (red) 0x99FF2B2B.toInt() else 0x6624D68A)
                var j = 0
                while (j + 8 < a.size) {
                    val v0 = mv(p.m, a[j], a[j + 1], a[j + 2]); val v1 = mv(p.m, a[j + 3], a[j + 4], a[j + 5]); val v2 = mv(p.m, a[j + 6], a[j + 7], a[j + 8])
                    val z0 = -(v0[2] + p.pz); val z1 = -(v1[2] + p.pz); val z2 = -(v2[2] + p.pz)
                    if (z0 > 0.05f && z1 > 0.05f && z2 > 0.05f) {
                        vBuf[nv++] = hw + p.f * (v0[0] + p.px) / z0; vBuf[nv++] = hh - p.f * (v0[1] + p.py) / z0
                        vBuf[nv++] = hw + p.f * (v1[0] + p.px) / z1; vBuf[nv++] = hh - p.f * (v1[1] + p.py) / z1
                        vBuf[nv++] = hw + p.f * (v2[0] + p.px) / z2; vBuf[nv++] = hh - p.f * (v2[1] + p.py) / z2
                        cBuf[nc++] = col; cBuf[nc++] = col; cBuf[nc++] = col
                    }
                    j += 9
                }
            }
            if (nc > 0 && fillLevel > 0) c.drawVertices(Canvas.VertexMode.TRIANGLES, nv, vBuf, 0, null, 0, cBuf, 0, null, 0, 0, fillPaint)
        }
        for (i in segs.indices) {
            val a = segs[i]
            val red = i < flags.size && flags[i]
            var j = 0
            while (j + 5 < a.size) {
                val v1 = mv(p.m, a[j], a[j + 1], a[j + 2])
                val v2 = mv(p.m, a[j + 3], a[j + 4], a[j + 5])
                val z1 = -(v1[2] + p.pz); val z2 = -(v2[2] + p.pz)
                if (z1 > 0.05f && z2 > 0.05f) {
                    val x1 = hw + p.f * (v1[0] + p.px) / z1; val y1 = hh - p.f * (v1[1] + p.py) / z1
                    val x2 = hw + p.f * (v2[0] + p.px) / z2; val y2 = hh - p.f * (v2[1] + p.py) / z2
                    if (red) { redBuf[nr++] = x1; redBuf[nr++] = y1; redBuf[nr++] = x2; redBuf[nr++] = y2 }
                    else if (isHole[i]) { holeBuf[nh++] = x1; holeBuf[nh++] = y1; holeBuf[nh++] = x2; holeBuf[nh++] = y2 }
                    else { okBuf[no++] = x1; okBuf[no++] = y1; okBuf[no++] = x2; okBuf[no++] = y2 }
                }
                j += 6
            }
        }
        c.drawLines(okBuf, 0, no, okPaint)
        c.drawLines(holeBuf, 0, nh, holePaint)
        c.drawLines(redBuf, 0, nr, redPaint)
        if (m.members.isEmpty()) return
    }

    private var lcx = 0f; private var lcy = 0f

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (fixed) return false
        sd.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { lx = e.x; ly = e.y }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (e.pointerCount == 2) {
                    lastAng = atan2(e.getY(1) - e.getY(0), e.getX(1) - e.getX(0))
                    lcx = (e.getX(0) + e.getX(1)) / 2f; lcy = (e.getY(0) + e.getY(1)) / 2f
                }
                lx = e.x; ly = e.y
            }
            MotionEvent.ACTION_MOVE -> {
                if (e.pointerCount == 1 && !sd.isInProgress) {
                    // یک انگشت: چرخش مدل (مثل 3D PDF Reader)
                    val dx = e.x - lx; val dy = e.y - ly; lx = e.x; ly = e.y
                    yaw += dx * 0.008f; pitch += dy * 0.008f
                    invalidate()
                } else if (e.pointerCount == 2) {
                    // دو انگشت: زوم (pinch) + جابه‌جایی + رول (چرخاندن)
                    val ang = atan2(e.getY(1) - e.getY(0), e.getX(1) - e.getX(0))
                    var da = ang - lastAng
                    if (da > Math.PI.toFloat()) da -= 2 * Math.PI.toFloat()
                    if (da < -Math.PI.toFloat()) da += 2 * Math.PI.toFloat()
                    roll += da
                    lastAng = ang
                    val mx = (e.getX(0) + e.getX(1)) / 2f; val my = (e.getY(0) + e.getY(1)) / 2f
                    val k = dist / focal()
                    tx += (mx - lcx) * k; ty -= (my - lcy) * k
                    lcx = mx; lcy = my
                    invalidate()
                }
            }
            MotionEvent.ACTION_POINTER_UP -> { lx = e.x; ly = e.y }
        }
        return true
    }
}

class QcCamActivity : AppCompatActivity(), SensorEventListener {
    private lateinit var previewView: PreviewView
    private lateinit var overlay: CamOverlay
    private lateinit var alarm: Alarm
    private lateinit var logo: ImageView
    private lateinit var tvFix: TextView
    private lateinit var tvMode: TextView
    private lateinit var tvTolM: TextView
    private lateinit var tvTolH: TextView
    private lateinit var tvMute: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvHint: TextView
    private lateinit var loadingTv: TextView
    private var blink: ObjectAnimator? = null
    private var tolM = 5f
    private var tolH = 3f
    private val exec = Executors.newSingleThreadExecutor()
    private var lastQc = 0L
    private var badCount = IntArray(0)
    private var goodCount = IntArray(0)
    private var sensorMgr: SensorManager? = null

    private val pickIfc = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            loadingTv.visibility = View.VISIBLE
            loadingTv.text = "در حال خواندن فایل…"
            IfcLoader.load(this, uri, { loadingTv.text = it }) { m, err ->
                loadingTv.visibility = View.GONE
                if (m != null) { setModel(m) }
                else Toast.makeText(this, "خطا در خواندن IFC: $err", Toast.LENGTH_LONG).show()
            }
        }
    }
    private val camPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startCamera() else Toast.makeText(this, "بدون اجازه‌ی دوربین، برنامه کار نمی‌کند", Toast.LENGTH_LONG).show()
    }

    private fun dp(v: Float) = (v * resources.displayMetrics.density).toInt()

    private fun mk(t: String, sp: Float = 17f, click: () -> Unit): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = sp
        tv.setTextColor(ContextCompat.getColor(this, R.color.btn_text))
        tv.setBackgroundResource(R.drawable.bg_btn3d)
        tv.gravity = Gravity.CENTER
        tv.setPadding(dp(14f), dp(10f), dp(14f), dp(10f))
        tv.isClickable = true
        tv.setOnClickListener { click() }
        return tv
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        val sp = getSharedPreferences("fabsteel", MODE_PRIVATE)
        tolM = sp.getFloat("camTolM", 5f); tolH = sp.getFloat("camTolH", 3f)
        alarm = Alarm(this)

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        previewView = PreviewView(this)
        previewView.scaleType = PreviewView.ScaleType.FILL_CENTER
        root.addView(previewView, FrameLayout.LayoutParams(-1, -1))
        overlay = CamOverlay(this)
        root.addView(overlay, FrameLayout.LayoutParams(-1, -1))

        // ستون دکمه‌ها (چپ)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        fun add(v: View) {
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(6f); col.addView(v, lp)
        }
        add(mk("Upload IFC / QCAR", 18f) { pickIfc.launch(arrayOf("*/*")) })
        tvMode = mk("📍 مارکر: روشن", 16f) {
            markerMode = !markerMode
            tvMode.text = if (markerMode) "📍 مارکر: روشن" else "📍 مارکر: خاموش"
            if (markerMode) Toast.makeText(this, "دوربین را روی مارکر چسبیده به قطعه بگیر", Toast.LENGTH_SHORT).show()
        }
        add(tvMode)
        val row2 = LinearLayout(this); row2.orientation = LinearLayout.HORIZONTAL
        row2.addView(mk("🖨 مارکر", 16f) { makeMarkerDialog() })
        var tvFill: TextView? = null
        tvFill = mk("◐ توپر", 16f) {
            overlay.fillLevel = if (overlay.fillLevel == 0) 2 else overlay.fillLevel - 1
            tvFill?.text = when (overlay.fillLevel) { 2 -> "◐ توپر"; 1 -> "◐ کم‌رنگ"; else -> "◐ خطی" }
            overlay.invalidate()
        }
        val lpf = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT); lpf.leftMargin = dp(6f)
        row2.addView(tvFill, lpf)
        add(row2)
        tvTolM = mk("", 16f) { askNumber("دقت اجزا (mm)", tolM) { tolM = it; sp.edit().putFloat("camTolM", it).apply(); refreshTol() } }
        add(tvTolM)
        tvTolH = mk("", 16f) { askNumber("دقت سوراخ‌کاری (mm)", tolH) { tolH = it; sp.edit().putFloat("camTolH", it).apply(); refreshTol() } }
        add(tvTolH)
        tvMute = mk("🔊 صدا", 16f) {
            alarm.muted = !alarm.muted
            tvMute.text = if (alarm.muted) "🔇 بی‌صدا" else "🔊 صدا"
        }
        add(tvMute)
        add(mk("⌂ منو", 16f) { finish() })
        val lpc = FrameLayout.LayoutParams(-2, -2, Gravity.START or Gravity.TOP)
        lpc.leftMargin = dp(10f); lpc.topMargin = dp(8f)
        root.addView(col, lpc)

        // لوگو بالا-راست (چشمک‌زن هنگام مغایرت)
        logo = ImageView(this)
        logo.setImageResource(R.drawable.fabsteel_logo)
        logo.scaleType = ImageView.ScaleType.FIT_CENTER
        val lpl = LinearLayout.LayoutParams(dp(64f), dp(64f))
        lpl.topMargin = dp(10f); lpl.gravity = Gravity.CENTER_HORIZONTAL
        col.addView(logo, lpl)

        // پنل وضعیت پایین-راست
        tvStatus = TextView(this)
        tvStatus.setTextColor(Color.WHITE); tvStatus.textSize = 16f
        tvStatus.setBackgroundColor(0xAA000000.toInt())
        tvStatus.setPadding(dp(12f), dp(8f), dp(12f), dp(8f))
        tvStatus.text = "مدل بارگذاری نشده"
        val lps = FrameLayout.LayoutParams(dp(260f), -2, Gravity.END or Gravity.BOTTOM)
        lps.rightMargin = dp(10f); lps.bottomMargin = dp(10f)
        root.addView(tvStatus, lps)

        // راهنما
        tvHint = TextView(this)
        tvHint.setTextColor(Color.WHITE); tvHint.textSize = 14f
        tvHint.setBackgroundColor(0x99000000.toInt())
        tvHint.setPadding(dp(10f), dp(6f), dp(10f), dp(6f))
        tvHint.gravity = Gravity.CENTER
        val lph = FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_HORIZONTAL or Gravity.BOTTOM)
        lph.bottomMargin = dp(86f)
        root.addView(tvHint, lph)

        // دکمه‌ی Fix
        tvFix = mk("FIX", 26f) { toggleFix() }
        tvFix.setPadding(dp(40f), dp(14f), dp(40f), dp(14f))
        val lpf = FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_HORIZONTAL or Gravity.BOTTOM)
        lpf.bottomMargin = dp(14f)
        root.addView(tvFix, lpf)

        loadingTv = TextView(this)
        loadingTv.setTextColor(Color.WHITE); loadingTv.textSize = 20f
        loadingTv.setBackgroundColor(0xCC000000.toInt())
        loadingTv.setPadding(dp(20f), dp(14f), dp(20f), dp(14f))
        loadingTv.visibility = View.GONE
        root.addView(loadingTv, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))

        setContentView(root)
        refreshTol(); refreshHint()
        ModelStore.model?.let { setModel(it) }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera()
        else camPerm.launch(Manifest.permission.CAMERA)
    }

    private fun refreshTol() {
        tvTolM.text = "دقت اجزا: ${trim(tolM)} mm"
        tvTolH.text = "دقت سوراخ: ${trim(tolH)} mm"
    }
    private fun trim(v: Float) = if (v == v.toInt().toFloat()) v.toInt().toString() else v.toString()

    private fun refreshHint() {
        tvHint.text = when {
            overlay.fixed -> "قفل شد؛ آرام دور قطعه بچرخ. برای تنظیم دوباره UNFIX بزن"
            ModelStore.model == null -> "دوربین را روی مارکر بگیر، یا IFC / فایل .qcar را آپلود کن"
            else -> "یک انگشت: چرخش | دو انگشت: زوم، جابه‌جایی، رول | روی قطعه بگذار و FIX بزن"
        }
        tvFix.text = if (overlay.fixed) "UNFIX" else "FIX"
    }

    private fun setModel(m: IfcModel) {
        overlay.setModel(m)
        badCount = IntArray(m.members.size); goodCount = IntArray(m.members.size)
        tvStatus.text = "${m.members.size} قطعه — مدل را روی قطعه بگذار"
        stopAlarm(); refreshHint()
        if (m.members.size > 3000) Toast.makeText(this, "این فایل کل پروژه است؛ برای QC فقط یک قطعه را خروجی بگیر", Toast.LENGTH_LONG).show()
    }

    private fun toggleFix() {
        if (ModelStore.model == null) { Toast.makeText(this, "اول خروجی IFC تکلا را آپلود کن", Toast.LENGTH_SHORT).show(); return }
        if (overlay.fixed) { overlay.unlock(); stopAlarm(); overlay.redFlags = BooleanArray(ModelStore.model!!.members.size) }
        else {
            overlay.lock()
            badCount = IntArray(ModelStore.model!!.members.size); goodCount = IntArray(ModelStore.model!!.members.size)
        }
        refreshHint()
    }

    private fun askNumber(title: String, cur: Float, ok: (Float) -> Unit) {
        val et = EditText(this)
        et.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        et.setText(trim(cur))
        AlertDialog.Builder(this).setTitle(title).setView(et)
            .setPositiveButton("OK") { _, _ ->
                val v = et.text.toString().replace(',', '.').toFloatOrNull()
                if (v != null && v > 0f && v < 1000f) ok(v)
            }.setNegativeButton("Cancel", null).show()
    }

    // ---------- دوربین ----------
    @Suppress("DEPRECATION")
    private fun startCamera() {
        val fut = ProcessCameraProvider.getInstance(this)
        fut.addListener({
            try {
                val provider = fut.get()
                val preview = Preview.Builder().setTargetAspectRatio(AspectRatio.RATIO_4_3).build()
                preview.setSurfaceProvider(previewView.surfaceProvider)
                val analysis = ImageAnalysis.Builder()
                    .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                analysis.setAnalyzer(exec) { img ->
                    try { analyze(img) } catch (t: Throwable) { diag("خطای تحلیل: ${t.javaClass.simpleName} ${t.message ?: ""}") } finally { img.close() }
                }
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
            } catch (t: Throwable) {
                Toast.makeText(this, "دوربین باز نشد: ${t.message}", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    // ---------- ردیابی مدل با تصویر + تحلیل مغایرت ----------
    private var luma = ByteArray(0)
    private var small = IntArray(0)
    private var dtm = IntArray(0)
    private var qualLabel = ""

    // ---------- مارکر QR (هلوگرام سیاه‌وسفید) ----------
    @Volatile private var markerMode = true
    private var scanBusy = false
    private var lastScan = 0L
    private var nv21 = ByteArray(0)
    private val qr by lazy { BarcodeScanning.getClient(BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build()) }
    private fun markMm(): Float = getSharedPreferences("fabsteel", MODE_PRIVATE).getFloat("markMm", 100f)

    private var lastDiag = 0L
    private var scanCount = 0
    private fun diag(msg: String) {
        if (overlay.fixed) return
        val now = System.currentTimeMillis()
        if (now - lastDiag < 400) return
        lastDiag = now
        runOnUiThread { if (!overlay.fixed) tvHint.text = msg }
    }

    private fun scanMarker(img: ImageProxy) {
        if (!markerMode || scanBusy) return
        val now = System.currentTimeMillis()
        if (now - lastScan < 120) return
        lastScan = now
        val w = img.width; val h = img.height
        val plane = img.planes[0]; val rs = plane.rowStride
        val buf = plane.buffer.duplicate()
        val total = w * h * 3 / 2
        if (nv21.size != total) nv21 = ByteArray(total)
        for (y in 0 until h) {
            val st = y * rs
            if (st + w > buf.limit()) return
            buf.position(st); buf.get(nv21, y * w, w)
        }
        java.util.Arrays.fill(nv21, w * h, total, 128.toByte())
        val rot = img.imageInfo.rotationDegrees
        val image = InputImage.fromByteArray(nv21, w, h, rot, InputImage.IMAGE_FORMAT_NV21)
        scanBusy = true
        val rotNow = overlay.rot?.clone()
        qr.process(image)
            .addOnSuccessListener { list ->
                scanBusy = false
                scanCount++
                if (list.isEmpty()) diag("اسکن فعال (v26)… مارکر پیدا نشد (${scanCount}) — فاصله ۳۰–۶۰ cm، نور کافی")
                else { diag("QR دیده شد: " + (list[0].rawValue ?: "?").take(40)); handleCodes(list, w, h, rot, rotNow) }
            }
            .addOnFailureListener { scanBusy = false; diag("خطای اسکن: ${it.message}") }
    }

    private var loadingId = ""
    private var missingId = ""
    private fun loadFromLibrary(id: String) {
        if (loadingId == id) return
        val f = java.io.File(java.io.File(filesDir, "qcar"), "$id.qcar")
        if (!f.exists()) {
            if (missingId != id) {
                missingId = id
                Toast.makeText(this, "مدل این مارکر در گوشی نیست؛ فایل .qcar را یک‌بار آپلود کن", Toast.LENGTH_LONG).show()
            }
            return
        }
        loadingId = id
        Thread {
            try {
                val d = f.inputStream().use { Qcar.read(it) }
                ModelStore.model = d.model; ModelStore.id = d.id
                runOnUiThread {
                    setModel(d.model)
                    Toast.makeText(this, "مدل «${d.name}» از روی مارکر بارگذاری شد", Toast.LENGTH_SHORT).show()
                    loadingId = ""
                }
            } catch (t: Throwable) {
                runOnUiThread { Toast.makeText(this, "خطا در خواندن qcar: ${t.message}", Toast.LENGTH_LONG).show(); loadingId = "" }
            }
        }.start()
    }

    private fun handleCodes(list: List<Barcode>, w: Int, h: Int, rot: Int, rotNow: FloatArray?) {
        val W = overlay.width.toFloat(); val H = overlay.height.toFloat()
        if (W == 0f) return
        for (b in list) {
            val txt = b.rawValue ?: continue
            val parts = txt.split("|")
            var id = ""; var face = -1; var codeMm = markMm(); var dyMm = 0f
            if (parts[0] == "FQ1" && parts.size >= 2) face = parts[1].toIntOrNull() ?: -1
            else if (parts[0] == "FQ2" && parts.size >= 4) {
                id = parts[1]; face = parts[2].toIntOrNull() ?: -1; codeMm = parts[3].toFloatOrNull() ?: markMm()
                if (parts.size >= 5) dyMm = parts[4].toFloatOrNull() ?: 0f
            } else continue
            val cp = b.cornerPoints ?: continue
            if (cp.size != 4 || face < 0 || face > 5) continue
            if (id.isNotEmpty() && id != ModelStore.id) { loadFromLibrary(id); return }
            val model = ModelStore.model ?: return
            val uw = if (rot % 180 == 0) w else h; val uh = if (rot % 180 == 0) h else w
            val sc = max(W / uw, H / uh)
            val ox = (W - uw * sc) / 2f; val oy = (H - uh * sc) / 2f
            val f = overlay.focal()
            val us = FloatArray(4); val vs = FloatArray(4)
            for (i in 0..3) { us[i] = (ox + cp[i].x * sc - W / 2f) / f; vs[i] = (oy + cp[i].y * sc - H / 2f) / f }
            val codeM = codeMm / 1000f
            val rc = markerPose(us, vs, codeM) ?: continue
            val first = overlay.setFromMarker(face, model.sizeM, rc, codeM, rotNow, dyMm / 1000f)
            if (first) {
                badCount = IntArray(model.members.size); goodCount = IntArray(model.members.size)
                refreshHint()
            }
            break
        }
    }

    private fun makeMarkerDialog() {
        if (ModelStore.model == null) { Toast.makeText(this, "اول مدل را بارگذاری کن", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this).setTitle("مارکر روی کدام وجه قطعه چسبانده می‌شود؟")
            .setItems(FACE_NAMES) { _, which ->
                askNumber("اندازه‌ی خودِ کد (mm) — پس از چاپ با خط‌کش اندازه بگیر", markMm()) { v ->
                    getSharedPreferences("fabsteel", MODE_PRIVATE).edit().putFloat("markMm", v).apply()
                    saveMarker(which, v)
                }
            }.show()
    }

    private fun saveMarker(face: Int, codeMm: Float) {
        try {
            val hints = mapOf<EncodeHintType, Any>(EncodeHintType.MARGIN to 0, EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M)
            val bm = QRCodeWriter().encode("FQ1|$face", BarcodeFormat.QR_CODE, 0, 0, hints)
            val mod = max(1, 900 / bm.width)
            val code = bm.width * mod
            val mg = code / 10
            val tot = code + 2 * mg
            val bmp = Bitmap.createBitmap(tot, tot, Bitmap.Config.ARGB_8888)
            val cv = Canvas(bmp)
            cv.drawColor(Color.WHITE)
            val pt = Paint(); pt.color = Color.BLACK
            for (y in 0 until bm.height) for (x in 0 until bm.width)
                if (bm.get(x, y)) cv.drawRect((mg + x * mod).toFloat(), (mg + y * mod).toFloat(), (mg + (x + 1) * mod).toFloat(), (mg + (y + 1) * mod).toFloat(), pt)
            val name = "FabQC_marker_face${face}_${codeMm.toInt()}mm.png"
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/FabQC")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            if (uri == null) { Toast.makeText(this, "ذخیره نشد", Toast.LENGTH_LONG).show(); return }
            contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            val total = (codeMm * 1.2f).toInt()
            AlertDialog.Builder(this).setTitle("مارکر ساخته شد")
                .setMessage("فایل در گالری، پوشه‌ی Pictures/FabQC ذخیره شد.\n\nچاپ: تصویر را با اندازه‌ی ${total}×${total} mm (۱۰۰٪، بدون Fit to page) چاپ کن؛ خودِ کد سیاه باید دقیقاً ${codeMm.toInt()} mm باشد. با خط‌کش بررسی کن و اگر فرق داشت، اندازه‌ی واقعی را دوباره وارد کن.\n\nچسباندن: وجه «${FACE_NAMES[face]}» مدل؛ گوشه‌ی پایین‌چپ کاغذ را روی گوشه‌ی پایین‌چپ همان وجه بچسبان (با خود کد، بالای کد به سمت بالای وجه). روی وجه بالا/پایین، بالای کد به سمت −Z/+Z است.")
                .setPositiveButton("OK", null).show()
        } catch (t: Throwable) {
            Toast.makeText(this, "خطا در ساخت مارکر: ${t.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun analyze(img: ImageProxy) {
        scanMarker(img)
        if (!overlay.fixed) return
        val model = ModelStore.model ?: return
        val n = model.members.size
        if (n == 0 || overlay.width == 0) return
        val rotDeg = img.imageInfo.rotationDegrees
        if (rotDeg != 0 && rotDeg != 180) return
        val plane = img.planes[0]
        val buf = plane.buffer
        val rs = plane.rowStride
        val w = img.width; val h = img.height
        val need = buf.remaining()
        if (luma.size < need) luma = ByteArray(need)
        buf.get(luma, 0, need)
        val sw = w / 2; val sh = h / 2
        if (small.size != sw * sh) { small = IntArray(sw * sh); dtm = IntArray(sw * sh) }
        val sm = small; val dm = dtm
        // کوچک‌سازی 2x2
        for (y in 0 until sh) {
            val r0 = 2 * y * rs; val r1 = r0 + rs
            for (x in 0 until sw) {
                val i0 = r0 + 2 * x; val i1 = r1 + 2 * x
                if (i1 + 1 >= need) { sm[y * sw + x] = 0; continue }
                sm[y * sw + x] = ((luma[i0].toInt() and 0xFF) + (luma[i0 + 1].toInt() and 0xFF) +
                    (luma[i1].toInt() and 0xFF) + (luma[i1 + 1].toInt() and 0xFF)) shr 2
            }
        }
        // آستانه‌ی لبه
        var sum = 0L; var cnt = 0
        for (y in 1 until sh - 1) {
            var x = 1
            while (x < sw - 1) {
                val i = y * sw + x
                sum += abs(sm[i + 1] - sm[i - 1]) + abs(sm[i + sw] - sm[i - sw]); cnt++; x += 3
            }
        }
        val thr = max(20f, 2.0f * sum.toFloat() / max(1, cnt))
        val INF = 100000
        for (y in 0 until sh) for (x in 0 until sw) {
            val i = y * sw + x
            if (x == 0 || y == 0 || x == sw - 1 || y == sh - 1) { dm[i] = INF; continue }
            val g = abs(sm[i + 1] - sm[i - 1]) + abs(sm[i + sw] - sm[i - sw])
            dm[i] = if (g > thr) 0 else INF
        }
        // نقشه‌ی فاصله تا نزدیک‌ترین لبه (chamfer 3-4)
        for (y in 1 until sh) for (x in 1 until sw - 1) {
            val i = y * sw + x
            var v = dm[i]
            v = min(v, dm[i - 1] + 3); v = min(v, dm[i - sw - 1] + 4)
            v = min(v, dm[i - sw] + 3); v = min(v, dm[i - sw + 1] + 4)
            dm[i] = v
        }
        for (y in sh - 2 downTo 0) for (x in sw - 2 downTo 1) {
            val i = y * sw + x
            var v = dm[i]
            v = min(v, dm[i + 1] + 3); v = min(v, dm[i + sw - 1] + 4)
            v = min(v, dm[i + sw] + 3); v = min(v, dm[i + sw + 1] + 4)
            dm[i] = v
        }

        val W = overlay.width.toFloat(); val H = overlay.height.toFloat()
        val s = max(W / w, H / h)
        val ox = (W - w * s) / 2f; val oy = (H - h * s) / 2f
        fun dtAt(sx: Float, sy: Float): Int {
            var ix = (sx - ox) / s; var iy = (sy - oy) / s
            if (rotDeg == 180) { ix = w - 1 - ix; iy = h - 1 - iy }
            val dx = (ix / 2f).toInt(); val dy = (iy / 2f).toInt()
            if (ix < 0f || iy < 0f || dx < 1 || dy < 1 || dx >= sw - 1 || dy >= sh - 1) return -1
            return dm[dy * sw + dx]
        }

        // ---------- ردیابی: اصلاح ۶ پارامتر پوز با کمینه‌کردن فاصله‌ی نقاط مدل تا لبه‌های تصویر ----------
        var label = ""
        val pts = overlay.trackPts
        val fitMode = overlay.fitFrames > 0
        if ((overlay.trackImage || fitMode) && pts.size >= 30) {
            val base = overlay.pose()
            val f = base.f
            val tau = 24f
            var hitCnt = 0; var inCnt = 0
            fun evalP(p: FloatArray, m: FloatArray, px: Float, py: Float, pz: Float, countHits: Boolean): Float {
                var sumC = 0f; var nn = 0
                var k = 0
                if (countHits) { hitCnt = 0; inCnt = 0 }
                while (k + 2 < pts.size) {
                    val x = pts[k]; val y = pts[k + 1]; val z = pts[k + 2]
                    k += 3
                    nn++
                    val vx = m[0] * x + m[1] * y + m[2] * z + px
                    val vy = m[3] * x + m[4] * y + m[5] * z + py
                    val vz = m[6] * x + m[7] * y + m[8] * z + pz
                    val d = -vz
                    if (d < 0.05f) { sumC += tau; continue }
                    val v = dtAt(W / 2f + f * vx / d, H / 2f - f * vy / d)
                    if (v < 0) { sumC += tau } else {
                        sumC += min(v.toFloat(), tau)
                        if (countHits) { inCnt++; if (v <= 9) hitCnt++ }
                    }
                }
                val reg = 0.004f * (abs(p[0]) + abs(p[1])) + 0.8f * abs(p[2]) + 1.5f * (abs(p[3]) + abs(p[4]) + abs(p[5]))
                return sumC / max(1, nn) + reg
            }
            fun compose(p: FloatArray): Array<Any> {
                val cm = mmul(rotZ(p[5]), mmul(rotX(p[3]), rotY(p[4])))
                val m = mmul(cm, base.m)
                val es = exp(p[2])
                val depth = -base.pz * es
                return arrayOf(m, base.px * es + p[0] * depth / f, base.py * es - p[1] * depth / f, -depth)
            }
            fun total(p: FloatArray, countHits: Boolean): Float {
                val c = compose(p)
                return evalP(p, c[0] as FloatArray, c[1] as Float, c[2] as Float, c[3] as Float, countHits)
            }
            val params = FloatArray(6)
            var best = total(params, false)
            val c0 = best
            val steps = floatArrayOf(14f, 14f, if (fitMode) 0.05f else 0f, 0.03f, 0.03f, 0.03f)
            for (round in 0 until 4) {
                for (pass in 0 until 2) {
                    var improved = false
                    for (i in 0..5) {
                        for (sg in 0..1) {
                            val old = params[i]
                            params[i] = old + (if (sg == 0) steps[i] else -steps[i])
                            val c = total(params, false)
                            if (c < best - 0.001f) { best = c; improved = true; break } else params[i] = old
                        }
                    }
                    if (!improved) break
                }
                for (i in 0..5) steps[i] *= 0.5f
            }
            total(params, true)
            val q = if (inCnt > 0) hitCnt.toFloat() / inCnt else 0f
            label = if (q >= 0.5f) "Tracking: Perfect" else if (q >= 0.3f) "Tracking: Good" else "Tracking: Poor"
            if (fitMode) {
                overlay.fitFrames = overlay.fitFrames - 1
                if (q >= 0.2f && best < c0 - 0.2f) {
                    val c = compose(params)
                    val ratio = -(c[3] as Float) / overlay.lockDepth
                    if (ratio in 0.7f..1.4f) overlay.applyFit(c[0] as FloatArray, c[1] as Float, c[2] as Float, c[3] as Float, overlay.rot?.clone())
                }
                overlay.fitStatus = if (overlay.fitFrames <= 0) "فیت خودکار انجام شد" else "فیت خودکار…"
            } else if (q >= 0.35f) {
                val c = compose(params)
                val dep = -(c[3] as Float)
                val ratio = dep / overlay.lockDepth
                if (ratio in 0.8f..1.25f)
                    overlay.setTracked(c[0] as FloatArray, c[1] as Float, c[2] as Float, c[3] as Float, overlay.rot?.clone())
            }
        }
        qualLabel = label

        // ---------- تحلیل مغایرت (هر ۰٫۵ ثانیه) ----------
        val now = System.currentTimeMillis()
        if (now - lastQc < 500) return
        lastQc = now
        val p = overlay.pose()
        val pxMm = p.f / (max(0.05f, abs(p.pz)) * 1000f)
        val ratio = FloatArray(n) { -1f }
        for (i in 0 until n) {
            val smp = overlay.samples.getOrNull(i) ?: continue
            val tol = if (overlay.isHole[i]) tolH else tolM
            val tolUnits = max(5f, 3f * (tol * pxMm) / s / 2f)
            var counted = 0; var hits = 0
            var k = 0
            while (k + 2 < smp.size) {
                val v = mv(p.m, smp[k], smp[k + 1], smp[k + 2])
                k += 3
                val z = -(v[2] + p.pz)
                if (z < 0.05f) continue
                val sx = p.w / 2f + p.f * (v[0] + p.px) / z
                val sy = p.h / 2f - p.f * (v[1] + p.py) / z
                val d = dtAt(sx, sy)
                if (d < 0) continue
                counted++
                if (d <= tolUnits) hits++
            }
            if (counted >= 4) ratio[i] = hits.toFloat() / counted
        }
        val valid = ratio.filter { it >= 0f }.sorted()
        if (valid.size < 2) { runOnUiThread { tvStatus.text = "مدل در تصویر دیده نمی‌شود؛ دوربین را به قطعه بگیر" }; return }
        val median = valid[valid.size / 2]
        val reds = BooleanArray(n)
        var redCount = 0
        val redNames = ArrayList<String>()
        val poorAlign = median < 0.12f
        for (i in 0 until n) {
            if (badCount.size <= i) break
            if (ratio[i] < 0f) { reds[i] = overlay.redFlags.getOrElse(i) { false }; if (reds[i]) redCount++; continue }
            val bad = !poorAlign && ratio[i] < 0.45f * median && ratio[i] < 0.3f
            if (bad) { badCount[i]++; goodCount[i] = 0 } else { goodCount[i]++; badCount[i] = 0 }
            val prev = overlay.redFlags.getOrElse(i) { false }
            reds[i] = if (!prev) badCount[i] >= 2 else goodCount[i] < 2
            if (reds[i]) { redCount++; if (redNames.size < 4) redNames.add(model.members[i].name) }
        }
        val effMm = max(max(tolM, tolH), 3.3f * s / max(1e-6f, pxMm))
        val okPct = ((n - redCount) * 100f / n).roundToInt()
        val head = (if (overlay.fitStatus.isNotEmpty()) overlay.fitStatus + "\n" else "") + (if (qualLabel.isNotEmpty()) qualLabel + "\n" else "") + "دقت تشخیص: ±" + effMm.roundToInt() + " mm\n"
        runOnUiThread {
            overlay.redFlags = reds
            overlay.invalidate()
            tvStatus.text = head + when {
                poorAlign -> "هم‌ترازی مدل با تصویر ضعیف است؛ Unfix بزن و مدل را دقیق‌تر روی قطعه بگذار"
                redCount > 0 -> "مغایرت: $redCount عضو\n" + redNames.joinToString("\n") + "\nتطابق $okPct%"
                else -> "تطابق $okPct% ✓"
            }
            if (redCount > 0 && !poorAlign) startAlarm() else stopAlarm()
        }
    }

    private fun startAlarm() {
        alarm.start()
        if (blink == null) {
            blink = ObjectAnimator.ofFloat(logo, View.ALPHA, 1f, 0.1f).apply {
                duration = 350; repeatMode = ObjectAnimator.REVERSE; repeatCount = ObjectAnimator.INFINITE; start()
            }
        }
    }
    private fun stopAlarm() {
        alarm.stop()
        blink?.cancel(); blink = null
        logo.alpha = 1f
    }

    // ---------- سنسور ----------
    override fun onResume() {
        super.onResume()
        val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        sensorMgr = sm
        val s = sm.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR) ?: sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        if (s != null) sm.registerListener(this, s, SensorManager.SENSOR_DELAY_GAME)
    }
    override fun onPause() {
        sensorMgr?.unregisterListener(this)
        stopAlarm()
        super.onPause()
    }
    override fun onDestroy() { stopAlarm(); exec.shutdown(); super.onDestroy() }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    @Suppress("DEPRECATION")
    override fun onSensorChanged(e: SensorEvent) {
        val r9 = FloatArray(9)
        SensorManager.getRotationMatrixFromVector(r9, e.values)
        val out = FloatArray(9)
        val rotation = windowManager.defaultDisplay.rotation
        val ax: Int; val ay: Int
        when (rotation) {
            Surface.ROTATION_90 -> { ax = SensorManager.AXIS_Y; ay = SensorManager.AXIS_MINUS_X }
            Surface.ROTATION_180 -> { ax = SensorManager.AXIS_MINUS_X; ay = SensorManager.AXIS_MINUS_Y }
            Surface.ROTATION_270 -> { ax = SensorManager.AXIS_MINUS_Y; ay = SensorManager.AXIS_X }
            else -> { ax = SensorManager.AXIS_X; ay = SensorManager.AXIS_Y }
        }
        SensorManager.remapCoordinateSystem(r9, ax, ay, out)
        overlay.rot = out
        if (overlay.fixed) overlay.invalidate()
    }
}
